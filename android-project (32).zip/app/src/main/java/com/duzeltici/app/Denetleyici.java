package com.duzeltici.app;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

/** Metni ücretsiz LanguageTool sunucusuna gönderip hataları ve doğru hâlini çıkarır. */
public class Denetleyici {

    private static final String ADRES = "https://api.languagetool.org/v2/check";

    public static class Hata {
        public int bas;
        public int uzunluk;
        public String kategori;
        public String yanlis;
        public String oneri;     // öneri yoksa null
        public String aciklama;  // LanguageTool'un İngilizce açıklaması
    }

    public static class Sonuc {
        public String yazilan;
        public String dogrusu;
        public boolean ingilizceDegil;
        public String dil = "";
        public final List<Hata> hatalar = new ArrayList<>();
    }

    private static final Pattern TURKCE_HARF = Pattern.compile("[çğıöşüÇĞİÖŞÜ]");
    private static final Pattern LATIN_HARF = Pattern.compile("[A-Za-z]");

    /** Türkçe yazılmış, çok kısa ya da sadece emoji olan mesajlar kontrol edilmez. */
    public static boolean denetlenmeli(String metin) {
        if (metin == null) return false;
        String t = metin.trim();
        if (t.length() < 2) return false;
        if (!LATIN_HARF.matcher(t).find()) return false;
        return !TURKCE_HARF.matcher(t).find();
    }

    /** İnternete bağlanır; ana iş parçacığında çağırma. Bağlantı sorunu olursa hata fırlatır. */
    public static Sonuc denetle(Context ctx, String metin) throws Exception {
        StringBuilder govde = new StringBuilder();
        govde.append("text=").append(URLEncoder.encode(metin, "UTF-8"));
        govde.append("&language=auto");
        govde.append("&preferredVariants=en-US");
        if (!Kayit.hepsiniGoster(ctx)) {
            // Sohbette önemsenmeyen büyük harf, noktalama ve boşluk uyarılarını kapat
            govde.append("&disabledCategories=")
                 .append(URLEncoder.encode("CASING,PUNCTUATION,TYPOGRAPHY", "UTF-8"));
        }

        HttpURLConnection c = (HttpURLConnection) new URL(ADRES).openConnection();
        String yanit;
        try {
            c.setRequestMethod("POST");
            c.setConnectTimeout(10000);
            c.setReadTimeout(15000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            c.setRequestProperty("Accept", "application/json");
            try (OutputStream os = c.getOutputStream()) {
                os.write(govde.toString().getBytes(StandardCharsets.UTF_8));
            }
            int kod = c.getResponseCode();
            if (kod != 200) throw new IOException("LanguageTool yanıt kodu: " + kod);
            yanit = oku(c.getInputStream());
        } finally {
            c.disconnect();
        }

        JSONObject j = new JSONObject(yanit);
        Sonuc s = new Sonuc();
        s.yazilan = metin;
        s.dogrusu = metin;

        JSONObject dil = j.optJSONObject("language");
        String dilKodu = dil != null ? dil.optString("code", "") : "";
        s.dil = dilKodu;
        if (!dilKodu.startsWith("en")) {
            s.ingilizceDegil = true;
            return s;
        }

        JSONArray eslesmeler = j.optJSONArray("matches");
        if (eslesmeler == null) return s;

        for (int i = 0; i < eslesmeler.length(); i++) {
            JSONObject m = eslesmeler.optJSONObject(i);
            if (m == null) continue;
            int bas = m.optInt("offset", -1);
            int uzunluk = m.optInt("length", 0);
            if (bas < 0 || uzunluk < 0 || bas + uzunluk > metin.length()) continue;

            String katId = "";
            String katAd = "";
            JSONObject kural = m.optJSONObject("rule");
            if (kural != null) {
                JSONObject kat = kural.optJSONObject("category");
                if (kat != null) {
                    katId = kat.optString("id", "");
                    katAd = kat.optString("name", "");
                }
            }

            String yanlis = metin.substring(bas, bas + uzunluk);

            // Cümle ortasında büyük harfle başlayan bilinmeyen kelime büyük ihtimalle bir isimdir (Ahmet, Ankara...)
            if ("TYPOS".equals(katId) && !yanlis.isEmpty()
                    && Character.isUpperCase(yanlis.charAt(0)) && !cumleBasi(metin, bas)) {
                continue;
            }

            String oneri = null;
            JSONArray oneriler = m.optJSONArray("replacements");
            if (oneriler != null && oneriler.length() > 0) {
                JSONObject ilk = oneriler.optJSONObject(0);
                if (ilk != null && ilk.has("value")) oneri = ilk.optString("value");
            }

            Hata h = new Hata();
            h.bas = bas;
            h.uzunluk = uzunluk;
            h.kategori = kategori(katId, katAd);
            h.yanlis = yanlis;
            h.oneri = oneri;
            h.aciklama = m.optString("message", "").replaceAll("</?suggestion>", "\"").trim();
            s.hatalar.add(h);
        }

        // Önerileri sondan başa uygulayarak doğru cümleyi kur
        List<Hata> sirali = new ArrayList<>(s.hatalar);
        Collections.sort(sirali, (a, b) -> b.bas - a.bas);
        StringBuilder dogru = new StringBuilder(metin);
        int sinir = metin.length();
        for (Hata h : sirali) {
            if (h.oneri == null) continue;
            if (h.bas + h.uzunluk > sinir) continue; // çakışan öneriyi atla
            dogru.replace(h.bas, h.bas + h.uzunluk, h.oneri);
            sinir = h.bas;
        }
        s.dogrusu = dogru.toString();
        return s;
    }

    private static boolean cumleBasi(String m, int bas) {
        int i = bas - 1;
        while (i >= 0 && m.charAt(i) == ' ') i--;
        if (i < 0) return true;
        char c = m.charAt(i);
        return c == '.' || c == '!' || c == '?' || c == '\n';
    }

    private static String kategori(String id, String ad) {
        switch (id) {
            case "TYPOS": return "Yazım hatası";
            case "GRAMMAR": return "Dilbilgisi";
            case "PUNCTUATION": return "Noktalama";
            case "CASING": return "Büyük/küçük harf";
            case "CONFUSED_WORDS": return "Karıştırılan kelime";
            case "COLLOCATIONS": return "Kelime uyumu";
            case "REDUNDANCY": return "Gereksiz tekrar";
            case "STYLE": return "Üslup";
            case "TYPOGRAPHY": return "Yazım düzeni";
            case "SEMANTICS": return "Anlam";
            case "NONSTANDARD_PHRASES": return "Standart dışı ifade";
            case "MISC": return "Diğer";
            default: return (ad == null || ad.isEmpty()) ? "Hata" : ad;
        }
    }

    private static String oku(InputStream in) throws IOException {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String satir;
            while ((satir = r.readLine()) != null) sb.append(satir).append('\n');
            return sb.toString();
        }
    }
}
