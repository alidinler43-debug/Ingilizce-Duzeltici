package com.duzeltici.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Arka planda yalnızca WhatsApp'ı izler. Mesaj kutusundaki yazıyı takip eder;
 * gönder tuşuna basılınca (ya da kutu bir anda boşalınca) metni kontrol ettirir.
 */
public class DuzelticiService extends AccessibilityService {

    private final ExecutorService isci = Executors.newSingleThreadExecutor();
    private String sonMetin = "";
    private String sonDenetlenen = "";
    private long sonDenetimZamani = 0;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Bildirim.kanalOlustur(this);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null) return;
        try {
            int tur = e.getEventType();
            if (tur == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                yaziDegisti(e);
            } else if (tur == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                tiklandi(e);
            }
        } catch (Exception ignored) {
        }
    }

    private void yaziDegisti(AccessibilityEvent e) {
        if (!mesajKutusu(e)) return;
        CharSequence once = e.getBeforeText();
        int eklenen = e.getAddedCount();
        int silinen = e.getRemovedCount();

        if (once != null && eklenen == 0 && silinen > 0 && silinen == once.length()) {
            // Kutu tamamen boşaldı
            sonMetin = "";
            if (silinen >= 2) gonderildi(once.toString()); // bir anda boşaldıysa mesaj gönderildi
            return;
        }
        sonMetin = metinAl(e);
    }

    private void tiklandi(AccessibilityEvent e) {
        boolean gonder = false;
        AccessibilityNodeInfo n = e.getSource();
        if (n != null) {
            String id = n.getViewIdResourceName();
            if (id != null && id.endsWith(":id/send")) gonder = true;
        }
        CharSequence aciklama = e.getContentDescription();
        if (!gonder && aciklama != null) {
            String a = aciklama.toString().trim().toLowerCase(Locale.ROOT);
            if (a.equals("send") || a.equals("gönder")) gonder = true;
        }
        if (gonder && sonMetin.trim().length() >= 2) {
            String m = sonMetin;
            sonMetin = "";
            gonderildi(m);
        }
    }

    /** Olay WhatsApp'ın mesaj yazma kutusundan mı geldi? (arama kutusu hariç) */
    private boolean mesajKutusu(AccessibilityEvent e) {
        AccessibilityNodeInfo n = e.getSource();
        String id = n != null ? n.getViewIdResourceName() : null;
        if (id != null) {
            if (id.endsWith(":id/entry")) return true;
            if (id.toLowerCase(Locale.ROOT).contains("search")) return false;
        }
        CharSequence sinif = e.getClassName();
        return sinif != null && sinif.toString().contains("EditText");
    }

    private String metinAl(AccessibilityEvent e) {
        AccessibilityNodeInfo n = e.getSource();
        if (n != null) {
            if (n.isShowingHintText()) return "";
            CharSequence t = n.getText();
            if (t != null) return t.toString();
        }
        List<CharSequence> parcalar = e.getText();
        StringBuilder sb = new StringBuilder();
        for (CharSequence p : parcalar) if (p != null) sb.append(p);
        return sb.toString();
    }

    private void gonderildi(String metin) {
        final String m = metin.trim();
        long simdi = System.currentTimeMillis();
        // Aynı mesaj hem tıklama hem kutunun boşalmasıyla iki kez yakalanabilir
        if (m.equals(sonDenetlenen) && simdi - sonDenetimZamani < 15000) return;
        sonDenetlenen = m;
        sonDenetimZamani = simdi;
        if (!Denetleyici.denetlenmeli(m)) return;

        final Context c = getApplicationContext();
        isci.execute(() -> {
            try {
                Denetleyici.Sonuc s = Denetleyici.denetle(c, m);
                if (!s.ingilizceDegil && !s.hatalar.isEmpty()) {
                    Kayit.ekle(c, s);
                    Bildirim.goster(c, s);
                }
            } catch (Exception ignored) {
                // İnternet yoksa sessizce geç
            }
        });
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        isci.shutdown();
        super.onDestroy();
    }
}
