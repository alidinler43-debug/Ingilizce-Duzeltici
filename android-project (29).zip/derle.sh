#!/bin/bash
# İngilizce Düzeltici: GitHub'da APK'yı derler (proje klasöründen çalışır)
set -eo pipefail
cd "$(dirname "$0")"
echo "Gradle indiriliyor..."
wget -q https://services.gradle.org/distributions/gradle-8.9-bin.zip -O /tmp/gradle.zip
unzip -q -o /tmp/gradle.zip -d "$HOME"
"$HOME/gradle-8.9/bin/gradle" assembleRelease --no-daemon --stacktrace
cp app/build/outputs/apk/release/app-release.apk "$GITHUB_WORKSPACE/Duzeltici.apk"
echo "APK hazır."
