package com.duzeltici.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Arka planda yalnızca WhatsApp'ı izler. Gönderilen İngilizce mesajı kontrol ettirir
 * ve sonucu ekranın üstünde küçük, sürüklenebilir bir kutuda gösterir.
 */
public class DuzelticiService extends AccessibilityService {

    private static final int KIRMIZI = 0xFFFF8A93;
    private static final int YESIL = 0xFF7CF0B8;
    private static final int SOLUK = 0xFFC9D3E3;

    private final ExecutorService isci = Executors.newSingleThreadExecutor();
    private final Handler anaIs = new Handler(Looper.getMainLooper());
    private final Runnable kapat = () -> kutuyuKapat();

    private String sonMetin = "";
    private String sonDenetlenen = "";
    private long sonDenetimZamani = 0;

    private WindowManager pencere;
    private View kutu;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null) return;
        try {
            int tur = e.getEventType();
            if (tur == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                yaziDegisti(e);
            } else if (tur == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                tiklandi(e);
            }
        } catch (Exception ignored) {
        }
    }

    // ---------- Gönderilen mesajı yakalama ----------

    private void yaziDegisti(AccessibilityEvent e) {
        if (!mesajKutusu(e)) return;
        CharSequence once = e.getBeforeText();
        int eklenen = e.getAddedCount();
        int silinen = e.getRemovedCount();

        if (once != null && eklenen == 0 && silinen > 0 && silinen == once.length()) {
            // Kutu tamamen boşaldı
            sonMetin = "";
            if (silinen >= 2) gonderildi(once.toString()); // bir anda boşaldıysa mesaj gönderildi
            return;
        }
        sonMetin = metinAl(e);
    }

    private void tiklandi(AccessibilityEvent e) {
        boolean gonder = false;
        AccessibilityNodeInfo n = e.getSource();
        if (n != null) {
            String id = n.getViewIdResourceName();
            if (id != null && id.endsWith(":id/send")) gonder = true;
        }
        CharSequence aciklama = e.getContentDescription();
        if (!gonder && aciklama != null) {
            String a = aciklama.toString().trim().toLowerCase(Locale.ROOT);
            if (a.equals("send") || a.equals("gönder")) gonder = true;
        }
        if (gonder && sonMetin.trim().length() >= 2) {
            String m = sonMetin;
            sonMetin = "";
            gonderildi(m);
        }
    }

    /** Olay WhatsApp'ın mesaj yazma kutusundan mı geldi? (arama kutusu hariç) */
    private boolean mesajKutusu(AccessibilityEvent e) {
        AccessibilityNodeInfo n = e.getSource();
        String id = n != null ? n.getViewIdResourceName() : null;
        if (id != null) {
            if (id.endsWith(":id/entry")) return true;
            if (id.toLowerCase(Locale.ROOT).contains("search")) return false;
        }
        CharSequence sinif = e.getClassName();
        return sinif != null && sinif.toString().contains("EditText");
    }

    private String metinAl(AccessibilityEvent e) {
        AccessibilityNodeInfo n = e.getSource();
        if (n != null) {
            if (n.isShowingHintText()) return "";
            CharSequence t = n.getText();
            if (t != null) return t.toString();
        }
        List<CharSequence> parcalar = e.getText();
        StringBuilder sb = new StringBuilder();
        for (CharSequence p : parcalar) if (p != null) sb.append(p);
        return sb.toString();
    }

    private void gonderildi(String metin) {
        final String m = metin.trim();
        long simdi = System.currentTimeMillis();
        // Aynı mesaj hem tıklama hem kutunun boşalmasıyla iki kez yakalanabilir
        if (m.equals(sonDenetlenen) && simdi - sonDenetimZamani < 15000) return;
        sonDenetlenen = m;
        sonDenetimZamani = simdi;
        if (!Denetleyici.denetlenmeli(m)) return;

        final Context c = getApplicationContext();
        isci.execute(() -> {
            Denetleyici.Sonuc s;
            try {
                s = Denetleyici.denetle(c, m);
            } catch (Exception hata) {
                anaIs.post(() -> uyariGoster("⚠️ İnternet yok, mesaj kontrol edilemedi"));
                return;
            }
            if (s.ingilizceDegil) return;
            if (!s.hatalar.isEmpty()) Kayit.ekle(c, s);
            if (s.hatalar.isEmpty() && !Kayit.dogruyuGoster(c)) return;
            final Denetleyici.Sonuc son = s;
            anaIs.post(() -> sonucGoster(son));
        });
    }

    // ---------- Ekrandaki küçük kutu ----------

    private void sonucGoster(Denetleyici.Sonuc s) {
        SpannableStringBuilder t = new SpannableStringBuilder();
        if (s.hatalar.isEmpty()) {
            ekle(t, "✅ " + s.yazilan, YESIL, false, false, 1f);
            ekle(t, "  doğru", SOLUK, false, false, 0.85f);
            kutuGoster(t, 5000);
            return;
        }
        ekle(t, "❌ ", KIRMIZI, false, false, 1f);
        ekle(t, s.yazilan, KIRMIZI, true, false, 1f);
        t.append("\n");
        if (s.dogrusu.equals(s.yazilan)) {
            ekle(t, "✅ öneri yok, ayrıntı uygulamada", SOLUK, false, false, 0.9f);
        } else {
            ekle(t, "✅ " + s.dogrusu, YESIL, false, true, 1f);
        }
        Set<String> turler = new LinkedHashSet<>();
        for (Denetleyici.Hata h : s.hatalar) turler.add(h.kategori);
        t.append("\n");
        ekle(t, String.join(", ", turler), SOLUK, false, false, 0.8f);
        kutuGoster(t, 12000);
    }

    private void uyariGoster(String yazi) {
        SpannableStringBuilder t = new SpannableStringBuilder();
        ekle(t, yazi, SOLUK, false, false, 0.9f);
        kutuGoster(t, 3500);
    }

    private void ekle(SpannableStringBuilder t, String s, int renk, boolean ustuCizili, boolean kalin, float boyut) {
        int b = t.length();
        t.append(s);
        int son = t.length();
        t.setSpan(new ForegroundColorSpan(renk), b, son, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (ustuCizili) t.setSpan(new StrikethroughSpan(), b, son, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (kalin) t.setSpan(new StyleSpan(Typeface.BOLD), b, son, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (boyut != 1f) t.setSpan(new RelativeSizeSpan(boyut), b, son, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    /** Kutuyu gösterir; dokununca kapanır, sürüklenince yeni yeri hatırlanır. */
    private void kutuGoster(CharSequence metin, long sure) {
        kutuyuKapat();
        try {
            if (pencere == null) pencere = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (pencere == null) return;

            TextView tv = new TextView(this);
            tv.setText(metin);
            tv.setTextColor(0xFFFFFFFF);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            tv.setLineSpacing(0, 1.1f);
            tv.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.9f));
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xF014213D);
            g.setCornerRadius(dp(14));
            g.setStroke(dp(1), 0x55FFFFFF);
            tv.setBackground(g);
            tv.setPadding(dp(14), dp(9), dp(14), dp(10));

            final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.x = Kayit.konumX(this);
            lp.y = Kayit.konumY(this, dp(72));

            tv.setOnTouchListener(new View.OnTouchListener() {
                private float bx, by;
                private int ilkX, ilkY;
                private boolean suruklendi;

                @Override
                public boolean onTouch(View v, MotionEvent ev) {
                    switch (ev.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            bx = ev.getRawX();
                            by = ev.getRawY();
                            ilkX = lp.x;
                            ilkY = lp.y;
                            suruklendi = false;
                            anaIs.removeCallbacks(kapat);
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            int dx = Math.round(ev.getRawX() - bx);
                            int dy = Math.round(ev.getRawY() - by);
                            if (!suruklendi && (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8))) suruklendi = true;
                            if (suruklendi) {
                                lp.x = ilkX + dx;
                                lp.y = Math.max(0, ilkY + dy);
                                try {
                                    pencere.updateViewLayout(v, lp);
                                } catch (Exception ignored) {
                                }
                            }
                            return true;
                        case MotionEvent.ACTION_UP:
                            if (suruklendi) {
                                Kayit.konumKaydet(getApplicationContext(), lp.x, lp.y);
                                anaIs.postDelayed(kapat, 6000);
                            } else {
                                kutuyuKapat();
                            }
                            return true;
                        case MotionEvent.ACTION_CANCEL:
                            anaIs.postDelayed(kapat, 6000);
                            return true;
                        default:
                            return false;
                    }
                }
            });

            pencere.addView(tv, lp);
            kutu = tv;
            anaIs.postDelayed(kapat, sure);
        } catch (Exception ignored) {
            kutu = null;
        }
    }

    private void kutuyuKapat() {
        anaIs.removeCallbacks(kapat);
        if (kutu != null && pencere != null) {
            try {
                pencere.removeView(kutu);
            } catch (Exception ignored) {
            }
        }
        kutu = null;
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        kutuyuKapat();
        isci.shutdown();
        super.onDestroy();
    }
}
