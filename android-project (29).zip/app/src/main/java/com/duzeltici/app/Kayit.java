package com.duzeltici.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/** Ayarları ve son 50 düzeltmeyi telefonda saklar. */
public class Kayit {

    private static final int EN_FAZLA = 50;

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("duzeltici", Context.MODE_PRIVATE);
    }

    public static boolean hepsiniGoster(Context c) {
        return p(c).getBoolean("hepsi", true);
    }

    public static void hepsiniGoster(Context c, boolean deger) {
        p(c).edit().putBoolean("hepsi", deger).apply();
    }

    public static boolean dogruyuGoster(Context c) {
        return p(c).getBoolean("dogru", true);
    }

    public static void dogruyuGoster(Context c, boolean deger) {
        p(c).edit().putBoolean("dogru", deger).apply();
    }

    public static int konumX(Context c) {
        return p(c).getInt("kx", 0);
    }

    public static int konumY(Context c, int varsayilan) {
        return p(c).getInt("ky", varsayilan);
    }

    public static void konumKaydet(Context c, int x, int y) {
        p(c).edit().putInt("kx", x).putInt("ky", y).apply();
    }

    public static void konumSifirla(Context c) {
        p(c).edit().remove("kx").remove("ky").apply();
    }

    public static synchronized void ekle(Context c, Denetleyici.Sonuc s) {
        try {
            JSONArray eski = gecmis(c);
            JSONArray yeni = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("z", System.currentTimeMillis());
            o.put("y", s.yazilan);
            o.put("d", s.dogrusu);
            o.put("a", Bildirim.ayrinti(s));
            yeni.put(o);
            for (int i = 0; i < eski.length() && yeni.length() < EN_FAZLA; i++) yeni.put(eski.get(i));
            p(c).edit().putString("gecmis", yeni.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public static JSONArray gecmis(Context c) {
        try {
            return new JSONArray(p(c).getString("gecmis", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static void temizle(Context c) {
        p(c).edit().remove("gecmis").apply();
    }
}
