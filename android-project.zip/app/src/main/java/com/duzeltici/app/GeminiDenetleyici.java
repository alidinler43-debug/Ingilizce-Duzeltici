package com.duzeltici.app;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Google Gemini ile cümle yapısını, kelime sırasını ve dilbilgisini düzeltir. */
public class GeminiDenetleyici {

    // Ücretsiz kullanımda açık olan modeller; ilk çalışan hatırlanır
    private static final String[] MODELLER = {
            "gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-flash-lite-latest",
            "gemini-flash-latest", "gemini-2.5-flash-lite", "gemini-2.5-flash"
    };

    /** tur: KOTA, ANAHTAR, ERISIM, MODEL, BAGLANTI, YANIT */
    public static class GeminiHatasi extends IOException {
        public final String tur;

        public GeminiHatasi(String tur, String mesaj) {
            super(tur + ": " + mesaj);
            this.tur = tur;
        }
    }

    public static Denetleyici.Sonuc denetle(Context ctx, String metin) throws GeminiHatasi {
        String anahtar = Kayit.geminiAnahtari(ctx);
        if (anahtar.isEmpty()) throw new GeminiHatasi("ANAHTAR", "anahtar girilmemiş");
        String tercih = Kayit.geminiModeli(ctx);
        List<String> sira = new ArrayList<>();
        if (!tercih.isEmpty()) sira.add(tercih);
        for (String m : MODELLER) if (!sira.contains(m)) sira.add(m);

        boolean hepsi = Kayit.hepsiniGoster(ctx);
        GeminiHatasi sonHata = null;
        for (String model : sira) {
            try {
                Denetleyici.Sonuc s = istek(anahtar, model, metin, hepsi);
                if (!model.equals(tercih)) Kayit.geminiModeli(ctx, model);
                s.motor = "Gemini (" + model + ")";
                return s;
            } catch (GeminiHatasi h) {
                sonHata = h;
                // Anahtar, erişim ya da internet sorunu bütün modelleri etkiler: hemen bildir
                if (h.tur.equals("ANAHTAR") || h.tur.equals("ERISIM") || h.tur.equals("BAGLANTI")) throw h;
                // Model yok, sınır doldu ya da yanıt bozuk: sıradaki modeli dene
            }
        }
        throw sonHata != null ? sonHata : new GeminiHatasi("MODEL", "uygun model bulunamadı");
    }

    private static String talimat(boolean hepsi) {
        return "You are a friendly English teacher for a Turkish speaker who chats on WhatsApp. "
                + "The user content is exactly one message they wrote. "
                + "If the message is mainly not English (for example Turkish), answer {\"ingilizce\": false}. "
                + "Otherwise check it like a teacher: grammar, word order, verb forms and tenses, "
                + "subject-verb agreement, articles, prepositions, plurals, spelling and wrong word choices. "
                + "Correct it into natural, correct English with the same meaning and a casual chat tone. "
                + "Do not change a message that is already correct and do not rephrase only for style. "
                + "Names of people and places (often Turkish, like Ayşe, Mehmet, Gülşen, Ankara) and Turkish "
                + "words mixed into the message are fine: keep them exactly as written and never list them as mistakes. "
                + "If most of the message is English, treat it as English. "
                + (hepsi ? "Also fix capitalization and punctuation. "
                         : "Ignore capitalization and all punctuation, including missing apostrophes "
                           + "(dont, didnt, im, its are fine) and missing periods or question marks; "
                           + "never list these as mistakes. ")
                + "Answer only with JSON exactly like: {\"ingilizce\": true, \"dogru\": false, "
                + "\"duzeltilmis\": \"the corrected message\", \"hatalar\": [{\"yanlis\": \"the wrong words exactly "
                + "as written (include a neighboring word if a word is missing)\", \"dogru\": \"the corrected words\", "
                + "\"aciklama\": \"very short reason in Turkish, at most 8 words\"}]}. "
                + "For word order mistakes put the whole wrongly ordered phrase in yanlis. "
                + "If there is no mistake answer {\"ingilizce\": true, \"dogru\": true, \"duzeltilmis\": \"\", \"hatalar\": []}.";
    }

    private static Denetleyici.Sonuc istek(String anahtar, String model, String metin, boolean hepsi) throws GeminiHatasi {
        String yanit;
        HttpURLConnection c = null;
        try {
            JSONObject govde = new JSONObject();
            govde.put("systemInstruction", new JSONObject().put("parts",
                    new JSONArray().put(new JSONObject().put("text", talimat(hepsi)))));
            govde.put("contents", new JSONArray().put(new JSONObject()
                    .put("role", "user")
                    .put("parts", new JSONArray().put(new JSONObject().put("text", metin)))));
            govde.put("generationConfig", new JSONObject()
                    .put("temperature", 0)
                    .put("responseMimeType", "application/json"));

            c = (HttpURLConnection) new URL("https://generativelanguage.googleapis.com/v1beta/models/"
                    + model + ":generateContent").openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(8000);
            c.setReadTimeout(20000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            c.setRequestProperty("x-goog-api-key", anahtar);
            try (OutputStream os = c.getOutputStream()) {
                os.write(govde.toString().getBytes(StandardCharsets.UTF_8));
            }
            int kod = c.getResponseCode();
            if (kod != 200) {
                String hata = "";
                try {
                    InputStream es = c.getErrorStream();
                    if (es != null) hata = oku(es);
                } catch (Exception ignored) {
                }
                String kisa = hataMesaji(hata);
                String kucuk = hata.toLowerCase(Locale.ROOT);
                if (kod == 429) throw new GeminiHatasi("KOTA", kisa);
                if (kod == 404) throw new GeminiHatasi("MODEL", kisa);
                if (kucuk.contains("api key") || kucuk.contains("api_key")) throw new GeminiHatasi("ANAHTAR", kisa);
                if (kucuk.contains("location")) throw new GeminiHatasi("ERISIM", kisa);
                if (kod == 401 || kod == 403) throw new GeminiHatasi("ERISIM", kisa);
                if (kod == 400) throw new GeminiHatasi("MODEL", kisa);
                throw new GeminiHatasi("YANIT", "HTTP " + kod + " " + kisa);
            }
            yanit = oku(c.getInputStream());
        } catch (GeminiHatasi h) {
            throw h;
        } catch (Exception e) {
            throw new GeminiHatasi("BAGLANTI", e.getClass().getSimpleName() + " " + e.getMessage());
        } finally {
            if (c != null) c.disconnect();
        }
        try {
            return cozumle(metin, yanit, hepsi);
        } catch (Exception e) {
            throw new GeminiHatasi("YANIT", "yanıt çözülemedi: " + e.getMessage());
        }
    }

    private static Denetleyici.Sonuc cozumle(String metin, String yanit, boolean hepsi) throws Exception {
        JSONObject j = new JSONObject(yanit);
        JSONArray adaylar = j.optJSONArray("candidates");
        if (adaylar == null || adaylar.length() == 0) throw new IOException("boş yanıt");
        JSONObject icerik = adaylar.getJSONObject(0).optJSONObject("content");
        JSONArray parcalar = icerik != null ? icerik.optJSONArray("parts") : null;
        StringBuilder sb = new StringBuilder();
        if (parcalar != null) {
            for (int i = 0; i < parcalar.length(); i++) {
                JSONObject p = parcalar.optJSONObject(i);
                if (p == null || p.optBoolean("thought", false)) continue;
                sb.append(p.optString("text", ""));
            }
        }
        String t = sb.toString();
        int a = t.indexOf('{');
        int b = t.lastIndexOf('}');
        if (a < 0 || b <= a) throw new IOException("JSON yok");
        JSONObject r = new JSONObject(t.substring(a, b + 1));

        Denetleyici.Sonuc s = new Denetleyici.Sonuc();
        s.yazilan = metin;
        s.dogrusu = metin;
        if (!r.optBoolean("ingilizce", true)) {
            s.ingilizceDegil = true;
            s.dil = "İngilizce değil";
            return s;
        }
        s.dil = "en";
        String duz = r.optString("duzeltilmis", "").trim();
        if (duz.isEmpty()) duz = metin;
        boolean dogru = r.optBoolean("dogru", false);
        if (dogru || ayni(duz, metin, hepsi)) return s; // hata yok

        s.dogrusu = duz;
        JSONArray h = r.optJSONArray("hatalar");
        if (h != null) {
            for (int i = 0; i < h.length(); i++) {
                JSONObject o = h.optJSONObject(i);
                if (o == null) continue;
                String yanlis = o.optString("yanlis", "").trim();
                String dogruParca = o.optString("dogru", "").trim();
                if (yanlis.isEmpty() && dogruParca.isEmpty()) continue;
                // Sadece noktalama / kesme işareti / büyük harf farkıysa gösterme
                if (!hepsi && sade(yanlis).equals(sade(dogruParca))) continue;
                // Tek kelimelik özel isim (Ayşe gibi) düzeltmesini gösterme
                if (!yanlis.contains(" ") && !yanlis.isEmpty() && Character.isUpperCase(yanlis.charAt(0))
                        && yanlis.matches(".*[çğıöşüÇĞİÖŞÜ].*")) continue;
                Denetleyici.Hata x = new Denetleyici.Hata();
                x.bas = -1;
                x.uzunluk = 0;
                x.kategori = "Düzeltme";
                x.yanlis = yanlis.isEmpty() ? "(eksik)" : yanlis;
                x.oneri = dogruParca;
                x.aciklama = o.optString("aciklama", "").trim();
                x.turkceAciklama = true;
                s.hatalar.add(x);
            }
        }
        if (s.hatalar.isEmpty()) {
            if (!hepsi) { // geriye yalnızca noktalama farkları kaldıysa cümle doğrudur
                s.dogrusu = metin;
                return s;
            }
            Denetleyici.Hata x = new Denetleyici.Hata();
            x.bas = -1;
            x.kategori = "Düzeltme";
            x.yanlis = metin;
            x.oneri = duz;
            x.aciklama = "";
            x.turkceAciklama = true;
            s.hatalar.add(x);
        }
        return s;
    }

    private static boolean ayni(String a, String b, boolean hepsi) {
        if (hepsi) return a.trim().equals(b.trim());
        return sade(a).equals(sade(b));
    }

    private static String sade(String s) {
        return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    private static String hataMesaji(String json) {
        try {
            String m = new JSONObject(json).getJSONObject("error").optString("message", "");
            return m.length() > 160 ? m.substring(0, 160) + "…" : m;
        } catch (Exception e) {
            return json.length() > 160 ? json.substring(0, 160) + "…" : json;
        }
    }

    private static String oku(InputStream in) throws IOException {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String satir;
            while ((satir = r.readLine()) != null) sb.append(satir).append('\n');
            return sb.toString();
        }
    }
}
