package com.duzeltici.app;

import android.content.Context;

import com.google.mediapipe.tasks.genai.llminference.LlmInference;
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Tablet içinde çalışan küçük yapay zekâ (Qwen2.5 1.5B, MediaPipe LLM Inference).
 * Mesajlar tabletten çıkmaz; model bir kez indirilir.
 */
public class YerelModel {

    public static final String ADRES = "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/"
            + "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task";
    private static final long TAHMINI_BOYUT = 1_598_000_000L;
    private static final String AD = "qwen2.5-1.5b-instruct-q8.task";

    // İndirme durumu (ekranda gösterilir)
    public static volatile boolean iniyor = false;
    public static volatile boolean iptal = false;
    public static volatile long inen = 0;
    public static volatile long toplam = 0;
    public static volatile String indirmeHatasi = null;

    private static LlmInference llm;

    public static File dosya(Context c) {
        return new File(new File(c.getFilesDir(), "model"), AD);
    }

    private static File parca(Context c) {
        return new File(new File(c.getFilesDir(), "model"), AD + ".part");
    }

    public static boolean hazir(Context c) {
        File f = dosya(c);
        return f.exists() && f.length() > 500_000_000L;
    }

    public static long parcaBoyutu(Context c) {
        File p = parca(c);
        return p.exists() ? p.length() : 0;
    }

    // =====================================================================
    // İndirme (yarıda kalırsa kaldığı yerden devam eder)
    // =====================================================================

    public static void indir(Context c) {
        if (iniyor) return;
        iniyor = true;
        iptal = false;
        indirmeHatasi = null;
        HttpURLConnection con = null;
        try {
            File p = parca(c);
            File klasor = p.getParentFile();
            if (klasor != null && !klasor.exists()) klasor.mkdirs();
            long mevcut = p.exists() ? p.length() : 0;
            long bos = c.getFilesDir().getUsableSpace();
            if (bos < (TAHMINI_BOYUT - mevcut) + 300_000_000L) {
                throw new IOException("Tablette yeterli boş yer yok (yaklaşık 2 GB gerekli)");
            }
            con = (HttpURLConnection) new URL(ADRES).openConnection();
            con.setInstanceFollowRedirects(true);
            con.setConnectTimeout(20000);
            con.setReadTimeout(60000);
            con.setRequestProperty("User-Agent", "IngilizceDuzeltici/1.0 (Android)");
            if (mevcut > 0) con.setRequestProperty("Range", "bytes=" + mevcut + "-");
            int kod = con.getResponseCode();
            boolean devam;
            if (kod == 206) {
                devam = true;
            } else if (kod == 200) {
                devam = false;
                mevcut = 0;
            } else if (kod == 416 && mevcut > 0) {
                bitir(c); // dosyanın tamamı zaten inmiş
                return;
            } else {
                throw new IOException("Sunucu yanıtı: HTTP " + kod);
            }
            long uzunluk = con.getContentLengthLong();
            toplam = uzunluk > 0 ? mevcut + uzunluk : TAHMINI_BOYUT;
            inen = mevcut;
            try (InputStream in = new BufferedInputStream(con.getInputStream(), 1 << 16);
                 OutputStream out = new BufferedOutputStream(new FileOutputStream(p, devam), 1 << 16)) {
                byte[] tampon = new byte[1 << 16];
                int n;
                while ((n = in.read(tampon)) != -1) {
                    if (iptal) throw new IOException("İndirme durduruldu");
                    out.write(tampon, 0, n);
                    inen += n;
                }
            }
            if (uzunluk > 0 && inen < toplam) throw new IOException("İndirme yarıda kaldı");
            bitir(c);
        } catch (Throwable t) {
            indirmeHatasi = t.getMessage() != null ? t.getMessage() : t.toString();
        } finally {
            if (con != null) con.disconnect();
            iniyor = false;
        }
    }

    private static void bitir(Context c) throws IOException {
        File p = parca(c);
        File f = dosya(c);
        if (f.exists()) f.delete();
        if (!p.renameTo(f)) throw new IOException("Model dosyası kaydedilemedi");
    }

    public static synchronized void sil(Context c) {
        kapat();
        dosya(c).delete();
        parca(c).delete();
    }

    public static synchronized void kapat() {
        if (llm != null) {
            try {
                llm.close();
            } catch (Throwable ignored) {
            }
            llm = null;
        }
    }

    // =====================================================================
    // Çalıştırma
    // =====================================================================

    private static synchronized LlmInference yukle(Context c) throws Exception {
        if (llm == null) {
            LlmInference.LlmInferenceOptions o = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(dosya(c).getAbsolutePath())
                    .setMaxTokens(320) // istem + kısa cevap; uzun boşa üretimi keser
                    .build();
            llm = LlmInference.createFromOptions(c.getApplicationContext(), o);
        }
        return llm;
    }

    /** Modeli önceden belleğe alır, ilk kontrol hızlı olsun diye. */
    public static void onYukle(Context c) {
        try {
            if (hazir(c)) yukle(c);
        } catch (Throwable ignored) {
        }
    }

    private static synchronized String uret(Context c, String istem) throws Exception {
        LlmInference m = yukle(c);
        LlmInferenceSession.LlmInferenceSessionOptions so =
                LlmInferenceSession.LlmInferenceSessionOptions.builder().setTopK(1).build();
        LlmInferenceSession s = LlmInferenceSession.createFromOptions(m, so);
        try {
            s.addQueryChunk(istem);
            return s.generateResponse();
        } finally {
            try {
                s.close();
            } catch (Throwable ignored) {
            }
        }
    }

    /** Kısa istem: model daha az okur, daha çabuk cevap verir. */
    private static String istem(String metin) {
        return "Fix the English grammar. Reply with the corrected sentence only.\n"
                + "Wrong: you was good\nRight: you were good\n"
                + "Wrong: where you going are\nRight: where are you going\n"
                + "Wrong: i trying learn english\nRight: i'm trying to learn english\n"
                + "Wrong: she want go home\nRight: she wants to go home\n"
                + "Wrong: " + metin.replace('\n', ' ').trim() + "\nRight:";
    }

    public static Denetleyici.Sonuc denetle(Context c, String metin) throws Exception {
        boolean hepsi = Kayit.hepsiniGoster(c);
        String duz = temizle(uret(c, istem(metin)));

        Denetleyici.Sonuc s = new Denetleyici.Sonuc();
        s.yazilan = metin;
        s.dogrusu = metin;
        s.dil = "en";
        s.motor = "Tablet içi yapay zekâ";
        if (duz.isEmpty() || !makul(metin, duz)) return s;

        List<String[]> farklar = farklar(metin.trim(), duz, hepsi);
        if (farklar.isEmpty()) return s;
        s.dogrusu = duz;
        for (String[] f : farklar) {
            Denetleyici.Hata x = new Denetleyici.Hata();
            x.bas = -1;
            x.kategori = "Düzeltme";
            x.yanlis = f[0];
            x.oneri = f[1];
            x.aciklama = "";
            s.hatalar.add(x);
        }
        return s;
    }

    /** Modelin cevabından yalnızca düzeltilmiş cümleyi alır. */
    private static String temizle(String cikti) {
        String t = cikti == null ? "" : cikti.replace("<|im_end|>", "").replace("<end_of_turn>", "")
                .replace("\\r", "\n").replace("\\n", "\n").replace("\\t", " ").trim();
        for (String satir : t.split("\n")) {
            String s = satir.trim();
            if (!s.isEmpty()) {
                t = s;
                break;
            }
        }
        String kucuk = t.toLowerCase(Locale.ROOT);
        if (kucuk.startsWith("right:")) t = t.substring(6).trim();
        else if (kucuk.startsWith("corrected:")) t = t.substring(10).trim();
        int kes = t.toLowerCase(Locale.ROOT).indexOf("wrong:");
        if (kes > 0) t = t.substring(0, kes).trim(); // örnek kalıbını sürdürdüyse kes
        t = t.replaceAll("[\\\\]+$", "").trim();
        if (t.length() >= 2 && ((t.startsWith("\"") && t.endsWith("\"")) || (t.startsWith("“") && t.endsWith("”")))) {
            t = t.substring(1, t.length() - 1).trim();
        }
        return t;
    }

    /** Model saçmaladıysa (çok uzun ya da alakasız cevap) düzeltmeyi gösterme. */
    private static boolean makul(String a, String b) {
        String[] aw = kelimeler(a);
        String[] bw = kelimeler(b);
        if (bw.length == 0) return false;
        if (bw.length > aw.length * 2 + 4) return false;
        if (aw.length == 0) return true;
        Set<String> bs = new HashSet<>(Arrays.asList(bw));
        int ortak = 0;
        for (String w : aw) if (bs.contains(w)) ortak++;
        return ortak * 10 >= aw.length * 4; // kelimelerin en az %40'ı ortak
    }

    private static String[] kelimeler(String s) {
        String t = s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9' ]", " ").trim();
        if (t.isEmpty()) return new String[0];
        return t.split("\\s+");
    }

    /** Yazılan ile düzeltilmiş cümle arasındaki farkları "yanlış → doğru" çiftlerine çevirir. */
    private static List<String[]> farklar(String a, String b, boolean hepsi) {
        String[] A = a.split("\\s+");
        String[] B = b.split("\\s+");
        int n = A.length;
        int m = B.length;
        int[][] L = new int[n + 1][m + 1];
        for (int i = n - 1; i >= 0; i--) {
            for (int j = m - 1; j >= 0; j--) {
                L[i][j] = esit(A[i], B[j], hepsi) ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
            }
        }
        List<String[]> gruplar = new ArrayList<>();
        boolean safVar = false; // yalnızca ekleme ya da yalnızca silme olan grup
        List<String> ga = new ArrayList<>();
        List<String> gb = new ArrayList<>();
        String onceki = null;
        int i = 0;
        int j = 0;
        while (i < n || j < m) {
            if (i < n && j < m && esit(A[i], B[j], hepsi)) {
                if (!ga.isEmpty() || !gb.isEmpty()) {
                    if (ga.isEmpty() || gb.isEmpty()) safVar = true;
                    gruplar.add(grupYap(ga, gb, onceki, A[i]));
                    ga.clear();
                    gb.clear();
                }
                onceki = A[i];
                i++;
                j++;
            } else if (i < n && (j == m || L[i + 1][j] >= L[i][j + 1])) {
                ga.add(A[i]);
                i++;
            } else {
                gb.add(B[j]);
                j++;
            }
        }
        if (!ga.isEmpty() || !gb.isEmpty()) {
            if (ga.isEmpty() || gb.isEmpty()) safVar = true;
            gruplar.add(grupYap(ga, gb, onceki, null));
        }
        // Kelime sırası değiştiyse ya da çok parça varsa tüm cümleyi tek parça göster
        if (gruplar.size() > 2 || (gruplar.size() == 2 && safVar)) {
            gruplar.clear();
            gruplar.add(new String[]{a, b});
        }
        return gruplar;
    }

    private static String[] grupYap(List<String> ga, List<String> gb, String onceki, String sonraki) {
        String sa = String.join(" ", ga);
        String sb = String.join(" ", gb);
        if (ga.isEmpty()) { // eksik kelime: yanındaki kelimeyle göster
            if (onceki != null) {
                sa = onceki;
                sb = onceki + " " + sb;
            } else if (sonraki != null) {
                sa = sonraki;
                sb = sb + " " + sonraki;
            }
        } else if (gb.isEmpty()) { // fazla kelime
            if (onceki != null) {
                sa = onceki + " " + sa;
                sb = onceki;
            } else if (sonraki != null) {
                sa = sa + " " + sonraki;
                sb = sonraki;
            }
        }
        return new String[]{sa, sb};
    }

    private static boolean esit(String x, String y, boolean hepsi) {
        if (hepsi) return x.equals(y);
        return sade(x).equals(sade(y));
    }

    private static String sade(String s) {
        return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9']", "");
    }
}
