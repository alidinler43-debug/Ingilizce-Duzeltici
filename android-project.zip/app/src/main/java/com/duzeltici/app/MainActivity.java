package com.duzeltici.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    // Renkler: lacivert mürekkep, öğretmen kalemi kırmızısı, doğru yeşili
    private static final int ARKA = 0xFFEEF2F6;
    private static final int KAGIT = 0xFFFFFFFF;
    private static final int MUREKKEP = 0xFF14213D;
    private static final int SOLUK = 0xFF5B6B82;
    private static final int KIRMIZI = 0xFFD62839;
    private static final int YESIL = 0xFF1B8A5A;

    private static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;
    private static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    private TextView durumErisim, durumPil, durumUstte, testSonuc, teshisMetni, baglantiSonucu, geminiDurum, geminiSonuc;
    private EditText anahtarKutu;
    private TextView modelDurum, modelSonuc;
    private LinearLayout gecmisKutu;
    private EditText testKutu;
    private final ExecutorService isci = Executors.newSingleThreadExecutor();
    private final Handler anaIs = new Handler(Looper.getMainLooper());
    private final Runnable teshisYenile = new Runnable() {
        @Override
        public void run() {
            teshisiGoster();
            anaIs.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Bildirim.kanalOlustur(this);
        getWindow().setStatusBarColor(MUREKKEP);

        ScrollView kaydir = new ScrollView(this);
        kaydir.setBackgroundColor(ARKA);
        kaydir.setFillViewport(true);
        LinearLayout kok = dikey();
        kaydir.addView(kok);
        setContentView(kaydir);

        // Üst bant: uygulamanın ne yaptığını örnekle gösterir
        LinearLayout bant = dikey();
        bant.setBackgroundColor(MUREKKEP);
        bant.setPadding(dp(20), dp(24), dp(20), dp(24));
        bant.addView(yazi("İngilizce Düzeltici", 26, KAGIT, true));
        TextView ornek = yazi("", 20, KAGIT, false);
        ornek.setText(ornekCumle());
        ((LinearLayout.LayoutParams) ornek.getLayoutParams()).topMargin = dp(14);
        bant.addView(ornek);
        TextView alt = yazi("WhatsApp açıkken ekranın köşesinde küçük bir kutu durur. İngilizce bir mesaj gönderdiğinde yanlış yazdığın her kelimeyi ve doğrusunu orada gösterir. Kutuyu sürükleyip istediğin yere koyabilirsin; dokununca küçülür, tekrar dokununca açılır.", 14, 0xFFC9D3E3, false);
        ((LinearLayout.LayoutParams) alt.getLayoutParams()).topMargin = dp(10);
        bant.addView(alt);
        TextView surum = yazi("Sürüm " + surumAdi(), 12, 0xFF8FA0BC, false);
        ((LinearLayout.LayoutParams) surum.getLayoutParams()).topMargin = dp(10);
        bant.addView(surum);
        kok.addView(bant);

        LinearLayout icerik = dikey();
        icerik.setPadding(dp(16), dp(4), dp(16), dp(40));
        kok.addView(icerik);

        // Kurulum
        LinearLayout kurulum = bolum(icerik, "Kurulum");
        durumErisim = adim(kurulum, "1. Erişilebilirlik izni", "İzni aç",
                v -> ac(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        kurulum.addView(yazi("Açılan sayfada “Yüklü uygulamalar” (veya “İndirilen uygulamalar”) → “İngilizce Düzeltici” → Aç.", 13, SOLUK, false));
        durumPil = adim(kurulum, "2. Pil kısıtlaması", "Kaldır", v -> pilMuafiyeti());
        durumUstte = adim(kurulum, "3. Diğer uygulamaların üzerinde göster", "İzin ver",
                v -> ac(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        kurulum.addView(yazi("Kutu normalde bu izin olmadan da çıkar; 3. adım, tablet izin vermezse kullanılan yedek yoldur.", 13, SOLUK, false));
        TextView gri = yazi("Erişilebilirlik anahtarı gri ve açılmıyorsa: aşağıdaki düğmeye bas, sağ üstteki ⋮ menüsünden “Kısıtlanmış ayarlara izin ver”i seç, sonra 1. adımı tekrarla.", 13, SOLUK, false);
        ((LinearLayout.LayoutParams) gri.getLayoutParams()).topMargin = dp(16);
        kurulum.addView(gri);
        kurulum.addView(dugme("Uygulama bilgisini aç", false,
                v -> ac(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())))));

        // Kontrol sistemi seçimi
        LinearLayout sistem = bolum(icerik, "Kontrol sistemi");
        final String[][] secenekler = {
                {"yerel", "Tablet içi yapay zekâ (internetsiz, ücretsiz)"},
                {"gemini", "Gemini (internet, ücretsiz anahtar)"},
                {"basit", "Basit kontrol (sadece yazım hataları)"}
        };
        RadioGroup rg = new RadioGroup(this);
        String etkin = Kontrol.etkinMotor(this);
        int seciliId = -1;
        for (int i = 0; i < secenekler.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(1000 + i);
            rb.setText(secenekler[i][1]);
            rb.setTextColor(MUREKKEP);
            rb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            rg.addView(rb);
            if (secenekler[i][0].equals(etkin)) seciliId = 1000 + i;
        }
        if (seciliId != -1) rg.check(seciliId);
        rg.setOnCheckedChangeListener((grup, id) -> {
            int k = id - 1000;
            if (k < 0 || k >= secenekler.length) return;
            Kayit.motor(MainActivity.this, secenekler[k][0]);
            if (secenekler[k][0].equals("yerel")) {
                final android.content.Context uyg = getApplicationContext();
                new Thread(() -> YerelModel.onYukle(uyg)).start();
            }
        });
        sistem.addView(rg);
        sistem.addView(yazi("Yapay zekâ seçiliyken mesaj gönderince kontrol edilir. Seçilen sistem çalışmazsa basit kontrol yapılır ve kutuda belirtilir.", 13, SOLUK, false));

        // Tablet içi yapay zekâ
        LinearLayout yerel = bolum(icerik, "Tablet içi yapay zekâ");
        yerel.addView(yazi("Mesajların tabletten hiç çıkmaz, internet ve anahtar gerekmez. Bir kez yaklaşık 1,6 GB'lık modeli indirmen gerekir (Wi-Fi'de indir, ekran açık kalsın). Mesaj başına birkaç saniye sürer; ilk kontrol modeli yüklerken daha uzun sürebilir. Gemini kadar iyi değildir ama kelime sırası ve dilbilgisi hatalarını düzeltir.", 13, SOLUK, false));
        modelDurum = yazi("", 14, MUREKKEP, true);
        yerel.addView(modelDurum);
        yerel.addView(dugme("Modeli indir / devam et", true, v -> {
            final android.content.Context uyg = getApplicationContext();
            new Thread(() -> YerelModel.indir(uyg)).start();
            anaIs.postDelayed(this::modelDurumunuGoster, 300);
        }));
        yerel.addView(dugme("İndirmeyi durdur", false, v -> YerelModel.iptal = true));
        yerel.addView(dugme("Modeli dene", false, v -> modeliDene()));
        yerel.addView(dugme("Modeli sil", false, v -> {
            YerelModel.sil(this);
            modelSonuc.setText("");
            modelDurumunuGoster();
        }));
        modelSonuc = yazi("", 14, MUREKKEP, false);
        modelSonuc.setTextIsSelectable(true);
        yerel.addView(modelSonuc);

        // Gemini: cümle yapısı ve kelime sırası
        LinearLayout gem = bolum(icerik, "Cümle yapısı (Gemini)");
        gem.addView(yazi("Kelime sırası ve dilbilgisi hatalarını düzeltmek için ücretsiz Gemini anahtarını buraya yapıştır. Anahtar yoksa yalnızca basit yazım kontrolü yapılır.", 13, SOLUK, false));
        geminiDurum = yazi("", 14, MUREKKEP, true);
        gem.addView(geminiDurum);
        gem.addView(dugme("1. Ücretsiz anahtar al", false,
                v -> ac(new Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))));
        anahtarKutu = new EditText(this);
        anahtarKutu.setHint("2. Anahtarı buraya yapıştır (AIza…)");
        anahtarKutu.setSingleLine(true);
        anahtarKutu.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        anahtarKutu.setTextColor(MUREKKEP);
        anahtarKutu.setHintTextColor(0xFF9AA5B8);
        anahtarKutu.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        anahtarKutu.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        gem.addView(anahtarKutu);
        gem.addView(dugme("3. Kaydet ve dene", true, v -> anahtariKaydetVeDene()));
        gem.addView(dugme("Anahtarı sil", false, v -> {
            Kayit.geminiAnahtari(this, "");
            Kayit.geminiModeli(this, "");
            geminiSonuc.setText("");
            geminiDurumunuGoster();
        }));
        geminiSonuc = yazi("", 14, MUREKKEP, false);
        geminiSonuc.setTextIsSelectable(true);
        gem.addView(geminiSonuc);

        // Durum: servisin WhatsApp'tan ne yakaladığını canlı gösterir
        LinearLayout durum = bolum(icerik, "Durum");
        teshisMetni = yazi("", 14, MUREKKEP, false);
        teshisMetni.setTextIsSelectable(true);
        durum.addView(teshisMetni);
        durum.addView(dugme("Kutuyu dene", true, v -> {
            DuzelticiService s = Teshis.servis;
            if (s == null) {
                Toast.makeText(this, "Servis çalışmıyor. Erişilebilirlik iznini kapatıp yeniden aç.", Toast.LENGTH_LONG).show();
            } else {
                s.ornekKutu();
            }
        }));
        durum.addView(dugme("Bağlantıyı dene", false, v -> baglantiyiDene()));
        baglantiSonucu = yazi("", 14, MUREKKEP, false);
        baglantiSonucu.setTextIsSelectable(true);
        durum.addView(baglantiSonucu);
        durum.addView(yazi("WhatsApp'ı açınca köşede kutu görünmüyorsa ya da mesajın kontrol edilmiyorsa buraya dönüp bak: hangi satırda takıldığı sorunun yerini gösterir.", 13, SOLUK, false));

        // Ayarlar
        LinearLayout ayar = bolum(icerik, "Ayarlar");
        CheckBox hepsi = new CheckBox(this);
        hepsi.setText("Büyük/küçük harf ve noktalama hatalarını da göster");
        hepsi.setTextColor(MUREKKEP);
        hepsi.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        hepsi.setChecked(Kayit.hepsiniGoster(this));
        hepsi.setOnCheckedChangeListener((d, secili) -> Kayit.hepsiniGoster(MainActivity.this, secili));
        ayar.addView(hepsi);
        ayar.addView(yazi("Kapatırsan sohbette çoğu kişinin önemsemediği uyarılar gelmez (örneğin “i am” yerine “I am”).", 13, SOLUK, false));

        CheckBox dogru = new CheckBox(this);
        dogru.setText("Doğru yazdığımda da göster");
        dogru.setTextColor(MUREKKEP);
        dogru.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        dogru.setChecked(Kayit.dogruyuGoster(this));
        dogru.setOnCheckedChangeListener((d, secili) -> Kayit.dogruyuGoster(MainActivity.this, secili));
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        dlp.topMargin = dp(12);
        dogru.setLayoutParams(dlp);
        ayar.addView(dogru);
        ayar.addView(yazi("Açıkken hatasız mesajlarda da kısa bir ✅ kutusu çıkar; böylece uygulamanın çalıştığını görürsün.", 13, SOLUK, false));
        CheckBox teshis = new CheckBox(this);
        teshis.setText("Kutuda okunan yazıyı göster (sorun ararken aç)");
        teshis.setTextColor(MUREKKEP);
        teshis.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        teshis.setChecked(Kayit.teshisSatiri(this));
        teshis.setOnCheckedChangeListener((d, secili) -> Kayit.teshisSatiri(MainActivity.this, secili));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        tlp.topMargin = dp(12);
        teshis.setLayoutParams(tlp);
        ayar.addView(teshis);
        ayar.addView(dugme("Kutunun yerini sıfırla", false, v -> {
            Kayit.konumSifirla(this);
            testSonuc.setTextColor(SOLUK);
            testSonuc.setText("Kutu yeniden sağ üst köşede çıkacak.");
        }));

        // Deneme
        LinearLayout dene = bolum(icerik, "Dene");
        dene.addView(yazi("WhatsApp'a gerek kalmadan buradan deneyebilirsin.", 13, SOLUK, false));
        testKutu = new EditText(this);
        testKutu.setHint("Örn: She don't like apples");
        testKutu.setTextColor(MUREKKEP);
        testKutu.setHintTextColor(0xFF9AA5B8);
        testKutu.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        testKutu.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        dene.addView(testKutu);
        dene.addView(dugme("Kontrol et", true, v -> testEt()));
        testSonuc = yazi("", 15, MUREKKEP, false);
        testSonuc.setTextIsSelectable(true);
        ((LinearLayout.LayoutParams) testSonuc.getLayoutParams()).topMargin = dp(12);
        dene.addView(testSonuc);

        // Geçmiş
        LinearLayout gecmis = bolum(icerik, "Son düzeltmeler");
        gecmisKutu = dikey();
        gecmisKutu.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        gecmis.addView(gecmisKutu);
        gecmis.addView(dugme("Geçmişi temizle", false, v -> {
            Kayit.temizle(this);
            gecmisiYukle();
        }));
    }

    @Override
    protected void onResume() {
        super.onResume();
        durumlariGuncelle();
        geminiDurumunuGoster();
        gecmisiYukle();
        anaIs.removeCallbacks(teshisYenile);
        anaIs.post(teshisYenile);
    }

    @Override
    protected void onPause() {
        anaIs.removeCallbacks(teshisYenile);
        super.onPause();
    }

    private void geminiDurumunuGoster() {
        String k = Kayit.geminiAnahtari(this);
        if (k.isEmpty()) {
            geminiDurum.setTextColor(SOLUK);
            geminiDurum.setText("Şu an: basit kontrol (LanguageTool). Gemini anahtarı girilmedi.");
        } else {
            String kisa = k.length() > 10 ? k.substring(0, 6) + "…" + k.substring(k.length() - 4) : k;
            String model = Kayit.geminiModeli(this);
            geminiDurum.setTextColor(YESIL);
            geminiDurum.setText("Şu an: Gemini ✅ (anahtar " + kisa + (model.isEmpty() ? "" : ", " + model) + ")");
        }
    }

    private void anahtariKaydetVeDene() {
        String k = anahtarKutu.getText().toString().trim().replace(" ", "");
        if (!k.isEmpty()) {
            Kayit.geminiAnahtari(this, k);
            Kayit.geminiModeli(this, "");
            anahtarKutu.setText("");
        }
        geminiDurumunuGoster();
        if (!Kayit.geminiVar(this)) {
            geminiSonuc.setTextColor(KIRMIZI);
            geminiSonuc.setText("Önce anahtarı kutuya yapıştır.");
            return;
        }
        geminiSonuc.setTextColor(SOLUK);
        geminiSonuc.setText("Gemini deneniyor…");
        final String ornek = "where you was going yesterday?";
        final long bas = System.currentTimeMillis();
        new Thread(() -> {
            String yazi;
            boolean basarili;
            try {
                Denetleyici.Sonuc s = GeminiDenetleyici.denetle(getApplicationContext(), ornek);
                double sn = (System.currentTimeMillis() - bas) / 1000.0;
                yazi = String.format(Locale.ROOT, "✅ Gemini çalışıyor (%.1f sn, %s)%n“%s” → “%s”",
                        sn, s.motor, ornek, s.dogrusu);
                basarili = true;
            } catch (GeminiDenetleyici.GeminiHatasi h) {
                yazi = "❌ " + Kontrol.turkce(h) + "\n" + h.getMessage();
                basarili = false;
            } catch (Throwable t) {
                yazi = "❌ " + t.getClass().getSimpleName() + ": " + t.getMessage();
                basarili = false;
            }
            final String sonuc = yazi;
            final boolean tamam = basarili;
            anaIs.post(() -> {
                geminiSonuc.setTextColor(tamam ? YESIL : KIRMIZI);
                geminiSonuc.setText(sonuc);
                geminiDurumunuGoster();
            });
        }).start();
    }

    /** Kontrol sunucusuna örnek bir cümle gönderip süreyi ve sonucu gösterir. */
    private void baglantiyiDene() {
        baglantiSonucu.setTextColor(SOLUK);
        baglantiSonucu.setText("Sunucuya bağlanılıyor…");
        final long bas = System.currentTimeMillis();
        new Thread(() -> {
            String yazi;
            boolean basarili;
            try {
                Denetleyici.Sonuc s = Kontrol.denetle(getApplicationContext(), "you was good");
                double sn = (System.currentTimeMillis() - bas) / 1000.0;
                yazi = String.format(Locale.ROOT, "✅ Bağlantı çalışıyor (%.1f sn, %s). “you was good” → %s",
                        sn, s.motor, s.dogrusu) + (s.not != null ? "\nℹ️ " + s.not : "");
                basarili = true;
            } catch (Throwable t) {
                double sn = (System.currentTimeMillis() - bas) / 1000.0;
                yazi = String.format(Locale.ROOT, "❌ Bağlantı kurulamadı (%.1f sn): %s: %s",
                        sn, t.getClass().getSimpleName(), t.getMessage());
                basarili = false;
            }
            final String sonuc = yazi;
            final boolean tamam = basarili;
            anaIs.post(() -> {
                baglantiSonucu.setTextColor(tamam ? YESIL : KIRMIZI);
                baglantiSonucu.setText(sonuc);
            });
        }).start();
    }

    private void modelDurumunuGoster() {
        if (modelDurum == null) return;
        if (YerelModel.iniyor) {
            long inen = YerelModel.inen / 1_000_000L;
            long toplam = Math.max(1, YerelModel.toplam / 1_000_000L);
            int yuzde = (int) Math.min(100, inen * 100 / toplam);
            modelDurum.setTextColor(MUREKKEP);
            modelDurum.setText("⬇️ İndiriliyor: %" + yuzde + " (" + inen + " / " + toplam + " MB)");
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            return;
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (YerelModel.hazir(this)) {
            modelDurum.setTextColor(YESIL);
            modelDurum.setText("✅ Model hazır (" + YerelModel.dosya(this).length() / 1_000_000L + " MB)");
            return;
        }
        long parca = YerelModel.parcaBoyutu(this) / 1_000_000L;
        if (YerelModel.indirmeHatasi != null) {
            modelDurum.setTextColor(KIRMIZI);
            modelDurum.setText("❌ " + YerelModel.indirmeHatasi
                    + (parca > 0 ? "\n" + parca + " MB indi; devam etmek için indir'e tekrar bas." : ""));
        } else if (parca > 0) {
            modelDurum.setTextColor(SOLUK);
            modelDurum.setText("⏸ Yarım kaldı: " + parca + " MB indi. Devam etmek için indir'e bas.");
        } else {
            modelDurum.setTextColor(SOLUK);
            modelDurum.setText("Model henüz indirilmedi.");
        }
    }

    private void modeliDene() {
        if (!YerelModel.hazir(this)) {
            modelSonuc.setTextColor(KIRMIZI);
            modelSonuc.setText("Önce modeli indir.");
            return;
        }
        modelSonuc.setTextColor(SOLUK);
        modelSonuc.setText("Model yükleniyor ve deneniyor… (ilk seferde biraz sürebilir)");
        final String ornek = "where you was going yesterday?";
        final long bas = System.currentTimeMillis();
        final android.content.Context uyg = getApplicationContext();
        new Thread(() -> {
            String yazi;
            boolean basarili;
            try {
                Denetleyici.Sonuc s = YerelModel.denetle(uyg, ornek);
                double sn = (System.currentTimeMillis() - bas) / 1000.0;
                yazi = String.format(Locale.ROOT, "✅ Model çalışıyor (%.1f sn)%n“%s” → “%s”", sn, ornek, s.dogrusu);
                basarili = true;
            } catch (Throwable t) {
                yazi = "❌ Model çalışmadı: " + t.getClass().getSimpleName() + ": " + t.getMessage();
                basarili = false;
            }
            final String sonuc = yazi;
            final boolean tamam = basarili;
            anaIs.post(() -> {
                modelSonuc.setTextColor(tamam ? YESIL : KIRMIZI);
                modelSonuc.setText(sonuc);
            });
        }).start();
    }

    private void teshisiGoster() {
        modelDurumunuGoster();
        SimpleDateFormat sf = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        StringBuilder sb = new StringBuilder();
        sb.append(Teshis.servis != null
                ? "✅ Servis çalışıyor"
                : "❌ Servis çalışmıyor (erişilebilirlik iznini kapatıp yeniden aç)");
        sb.append("\nWhatsApp'tan son sinyal: ")
          .append(Teshis.sonSinyal == 0 ? "henüz yok" : sf.format(new Date(Teshis.sonSinyal)));
        sb.append("\nYazı alanı: ").append(Teshis.alanBilgisi == null ? "henüz aranmadı" : Teshis.alanBilgisi);
        sb.append("\nSon olay: ").append(Teshis.sonOlay == null ? "henüz yok" : Teshis.sonOlay);
        sb.append("\nSon değişim: ").append(Teshis.sonAday == null ? "henüz yok" : Teshis.sonAday);
        sb.append("\nSon yakalanan mesaj: ");
        if (Teshis.sonYakalanan == null) {
            sb.append("henüz yok");
        } else {
            sb.append("“").append(Teshis.sonYakalanan).append("” (")
              .append(sf.format(new Date(Teshis.sonYakalananZaman))).append(")");
        }
        sb.append("\nSon kontrol sonucu: ").append(Teshis.sonSonuc == null ? "henüz yok" : Teshis.sonSonuc);
        if (Teshis.kutuHatasi != null) sb.append("\nKutu hatası: ").append(Teshis.kutuHatasi);
        teshisMetni.setText(sb.toString());
    }

    private String surumAdi() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "?";
        }
    }

    @Override
    protected void onDestroy() {
        isci.shutdown();
        super.onDestroy();
    }

    // ---------- Kurulum durumları ----------

    private void durumlariGuncelle() {
        durumYaz(durumErisim, erisimAcik());
        PowerManager pm = getSystemService(PowerManager.class);
        durumYaz(durumPil, pm != null && pm.isIgnoringBatteryOptimizations(getPackageName()));
        durumYaz(durumUstte, Settings.canDrawOverlays(this));
    }

    private void durumYaz(TextView t, boolean tamam) {
        t.setText(tamam ? "✅ Tamam" : "❌ Yapılmadı");
        t.setTextColor(tamam ? YESIL : KIRMIZI);
    }

    private boolean erisimAcik() {
        String acik = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (acik == null) return false;
        ComponentName cn = new ComponentName(this, DuzelticiService.class);
        String a = acik.toLowerCase();
        return a.contains(cn.flattenToString().toLowerCase()) || a.contains(cn.flattenToShortString().toLowerCase());
    }

    private void pilMuafiyeti() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            ac(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    private void ac(Intent i) {
        try {
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception ignored) {
            }
        }
    }

    // ---------- Deneme ----------

    private void testEt() {
        final String m = testKutu.getText().toString().trim();
        if (m.isEmpty()) return;
        if (!Denetleyici.denetlenmeli(m)) {
            testSonuc.setTextColor(SOLUK);
            testSonuc.setText("Bu metin kontrol edilmez: Türkçe harf (ç, ğ, ı, ö, ş, ü) içeriyor ya da çok kısa.");
            return;
        }
        testSonuc.setTextColor(SOLUK);
        testSonuc.setText("Kontrol ediliyor…");
        isci.execute(() -> {
            try {
                Denetleyici.Sonuc s = Kontrol.denetle(getApplicationContext(), m);
                anaIs.post(() -> testSonucuGoster(s));
            } catch (Exception e) {
                anaIs.post(() -> {
                    testSonuc.setTextColor(KIRMIZI);
                    testSonuc.setText("Sunucuya bağlanılamadı. İnternetini kontrol edip tekrar dene.");
                });
            }
        });
    }

    private void testSonucuGoster(Denetleyici.Sonuc s) {
        if (s.ingilizceDegil) {
            testSonuc.setTextColor(SOLUK);
            testSonuc.setText("Bu metin İngilizce olarak algılanmadı, kontrol edilmedi.");
            return;
        }
        if (s.hatalar.isEmpty()) {
            testSonuc.setTextColor(YESIL);
            testSonuc.setText("✅ Hata bulunamadı, doğru yazmışsın.");
            return;
        }
        testSonuc.setTextColor(MUREKKEP);
        testSonuc.setText(Bildirim.metin(s) + (s.not != null ? "\n\nℹ️ " + s.not : "")
                + "\n\nKontrol: " + s.motor + ". WhatsApp'ta bu sonuç köşedeki kutuda çıkar.");
    }

    // ---------- Geçmiş ----------

    private void gecmisiYukle() {
        gecmisKutu.removeAllViews();
        JSONArray a = Kayit.gecmis(this);
        if (a.length() == 0) {
            gecmisKutu.addView(yazi("Henüz düzeltme yok. WhatsApp'ta hatalı bir İngilizce mesaj gönderdiğinde burada da görünür.", 14, SOLUK, false));
            return;
        }
        DateFormat df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            TextView zaman = yazi(df.format(new Date(o.optLong("z"))), 12, SOLUK, false);
            ((LinearLayout.LayoutParams) zaman.getLayoutParams()).topMargin = dp(i == 0 ? 6 : 18);
            gecmisKutu.addView(zaman);

            String yazilan = o.optString("y");
            String dogru = o.optString("d");
            TextView ozet = yazi("❌ " + yazilan + "\n✅ " + (dogru.equals(yazilan) ? "öneri yok" : dogru), 15, MUREKKEP, false);
            ozet.setTextIsSelectable(true);
            gecmisKutu.addView(ozet);

            String ayrinti = o.optString("a");
            if (!ayrinti.isEmpty()) gecmisKutu.addView(yazi(ayrinti, 13, SOLUK, false));
        }
    }

    // ---------- Görünüm yardımcıları ----------

    private CharSequence ornekCumle() {
        SpannableStringBuilder s = new SpannableStringBuilder("She ");
        int b1 = s.length();
        s.append("don't");
        s.setSpan(new StrikethroughSpan(), b1, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        s.setSpan(new ForegroundColorSpan(0xFFFF7A85), b1, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        s.append(" ");
        int b2 = s.length();
        s.append("doesn't");
        s.setSpan(new ForegroundColorSpan(0xFF6EE7B0), b2, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        s.setSpan(new StyleSpan(Typeface.BOLD), b2, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        s.append(" like apples.");
        return s;
    }

    private LinearLayout bolum(LinearLayout ust, String baslik) {
        LinearLayout k = dikey();
        GradientDrawable g = new GradientDrawable();
        g.setColor(KAGIT);
        g.setCornerRadius(dp(14));
        k.setBackground(g);
        k.setPadding(dp(16), dp(14), dp(16), dp(16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = dp(16);
        k.setLayoutParams(lp);
        k.addView(yazi(baslik, 18, MUREKKEP, true));
        ust.addView(k);
        return k;
    }

    private TextView adim(LinearLayout ust, String baslik, String dugmeYazi, View.OnClickListener l) {
        LinearLayout satir = new LinearLayout(this);
        satir.setOrientation(LinearLayout.HORIZONTAL);
        satir.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(MATCH, WRAP);
        slp.topMargin = dp(14);
        satir.setLayoutParams(slp);

        LinearLayout sol = dikey();
        sol.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        sol.addView(yazi(baslik, 16, MUREKKEP, true));
        TextView durum = yazi("", 14, SOLUK, false);
        sol.addView(durum);
        satir.addView(sol);

        Button d = dugme(dugmeYazi, true, l);
        ((LinearLayout.LayoutParams) d.getLayoutParams()).topMargin = 0;
        satir.addView(d);
        ust.addView(satir);
        return durum;
    }

    private Button dugme(String yazi, boolean dolu, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(yazi);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setStateListAnimator(null);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(10));
        if (dolu) {
            g.setColor(MUREKKEP);
            b.setTextColor(KAGIT);
        } else {
            g.setColor(KAGIT);
            g.setStroke(dp(1), MUREKKEP);
            b.setTextColor(MUREKKEP);
        }
        b.setBackground(g);
        b.setPadding(dp(18), dp(10), dp(18), dp(10));
        b.setMinHeight(dp(44));
        b.setMinimumHeight(dp(44));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private TextView yazi(String s, int sp, int renk, boolean kalin) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(renk);
        if (kalin) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLineSpacing(0, 1.15f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = dp(4);
        t.setLayoutParams(lp);
        return t;
    }

    private LinearLayout dikey() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
