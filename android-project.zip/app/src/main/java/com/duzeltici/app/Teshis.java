package com.duzeltici.app;

/** Uygulama ekranındaki "Durum" bölümü için servisten gelen anlık bilgiler. */
public class Teshis {
    public static volatile DuzelticiService servis;
    public static volatile long sonSinyal;
    public static volatile String sonYakalanan;
    public static volatile long sonYakalananZaman;
    public static volatile String sonSonuc;
    public static volatile String kutuHatasi;
    public static volatile String alanBilgisi;
    public static volatile String sonOlay;
    public static volatile String sonAday;
}
