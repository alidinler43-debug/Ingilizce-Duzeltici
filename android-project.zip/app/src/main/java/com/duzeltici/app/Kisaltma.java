package com.duzeltici.app;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Noktalama, kesme işareti ve kısaltma farklarını yok sayarak iki yazıyı karşılaştırmak için.
 * its = it's = it is, dont = don't = do not, im = I'm = I am ... hepsi aynı sayılır.
 */
public class Kisaltma {

    private static final Map<String, String> ACILIM = new HashMap<>();

    static {
        String[][] liste = {
                {"im", "i am"}, {"ive", "i have"}, {"ill", "i will"}, {"id", "i would"},
                {"youre", "you are"}, {"youve", "you have"}, {"youll", "you will"}, {"youd", "you would"},
                {"hes", "he is"}, {"shes", "she is"}, {"its", "it is"},
                {"theyre", "they are"}, {"theyve", "they have"}, {"theyll", "they will"}, {"theyd", "they would"},
                {"weve", "we have"}, {"thats", "that is"}, {"whats", "what is"}, {"wheres", "where is"},
                {"whos", "who is"}, {"hows", "how is"}, {"theres", "there is"}, {"heres", "here is"},
                {"lets", "let us"}, {"dont", "do not"}, {"doesnt", "does not"}, {"didnt", "did not"},
                {"cant", "can not"}, {"cannot", "can not"}, {"wont", "will not"}, {"isnt", "is not"},
                {"arent", "are not"}, {"wasnt", "was not"}, {"werent", "were not"}, {"havent", "have not"},
                {"hasnt", "has not"}, {"hadnt", "had not"}, {"wouldnt", "would not"}, {"couldnt", "could not"},
                {"shouldnt", "should not"}, {"mustnt", "must not"}, {"aint", "am not"}
        };
        for (String[] k : liste) ACILIM.put(k[0], k[1]);
    }

    /** Karşılaştırma için sade biçim: küçük harf, noktalama yok, kısaltmalar açılmış. */
    public static String kanonik(String s) {
        if (s == null) return "";
        String t = s.toLowerCase(Locale.ROOT).replace('’', '\'').replace('‘', '\'');
        StringBuilder sb = new StringBuilder();
        for (String w : t.split("[^a-z0-9']+")) {
            String k = w.replace("'", "");
            if (k.isEmpty()) continue;
            String a = ACILIM.get(k);
            sb.append(a != null ? a : k).append(' ');
        }
        return sb.toString().replace(" ", "");
    }

    /** Aradaki tek fark noktalama, kesme işareti, büyük harf ya da kısaltma mı? */
    public static boolean ayni(String a, String b) {
        return kanonik(a).equals(kanonik(b));
    }
}
