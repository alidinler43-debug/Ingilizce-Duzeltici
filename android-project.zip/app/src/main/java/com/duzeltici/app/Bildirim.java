package com.duzeltici.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/** Hata bulunduğunda "Yanlış / Doğrusu" bildirimini gösterir. */
public class Bildirim {

    private static final String KANAL = "duzeltmeler";
    private static int sayac = 1;

    public static void kanalOlustur(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null || nm.getNotificationChannel(KANAL) != null) return;
        NotificationChannel kanal = new NotificationChannel(
                KANAL, "Düzeltmeler", NotificationManager.IMPORTANCE_HIGH);
        kanal.setDescription("Gönderdiğin İngilizce mesajdaki hatalar");
        nm.createNotificationChannel(kanal);
    }

    /** Her hatanın türü, yanlış kısmı, önerisi ve açıklaması. */
    public static String ayrinti(Denetleyici.Sonuc s) {
        StringBuilder sb = new StringBuilder();
        for (Denetleyici.Hata h : s.hatalar) {
            if (sb.length() > 0) sb.append("\n\n");
            sb.append("• ").append(h.kategori).append(": “").append(h.yanlis).append("”");
            if (h.oneri != null) sb.append(" → “").append(h.oneri).append("”");
            if (h.aciklama != null && !h.aciklama.isEmpty()) sb.append("\n").append(h.aciklama);
        }
        return sb.toString();
    }

    public static String metin(Denetleyici.Sonuc s) {
        String dogru = s.dogrusu.equals(s.yazilan)
                ? "öneri bulunamadı, açıklamaya bak"
                : s.dogrusu;
        return "❌ Yazdığın: " + s.yazilan + "\n✅ Doğrusu: " + dogru + "\n\n" + ayrinti(s);
    }

    public static synchronized void goster(Context c, Denetleyici.Sonuc s) {
        kanalOlustur(c);
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;

        Intent ac = new Intent(c, MainActivity.class);
        ac.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                c, 0, ac, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        int adet = s.hatalar.size();
        String baslik = adet == 1 ? "1 hata bulundu" : adet + " hata bulundu";
        String kisa = s.dogrusu.equals(s.yazilan) ? s.yazilan : "✅ " + s.dogrusu;

        Notification n = new Notification.Builder(c, KANAL)
                .setSmallIcon(R.drawable.ic_bildirim)
                .setContentTitle("✏️ " + baslik)
                .setContentText(kisa)
                .setStyle(new Notification.BigTextStyle().bigText(metin(s)))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        try {
            nm.notify(sayac++, n);
        } catch (SecurityException ignored) {
        }
    }
}
