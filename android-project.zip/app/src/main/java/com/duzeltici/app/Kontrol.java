package com.duzeltici.app;

import android.content.Context;

/**
 * Kontrol sistemini seçer: tablet içi yapay zekâ, Gemini ya da basit kontrol (LanguageTool).
 * Seçilen sistem çalışmazsa basit kontrole geçer ve bunu sonuçta belirtir.
 */
public class Kontrol {

    public static String etkinMotor(Context c) {
        String m = Kayit.motor(c);
        if (m.equals("yerel") || m.equals("gemini") || m.equals("basit")) return m;
        if (YerelModel.hazir(c)) return "yerel";
        if (Kayit.geminiVar(c)) return "gemini";
        return "basit";
    }

    public static Denetleyici.Sonuc denetle(Context c, String m) throws Exception {
        String motor = etkinMotor(c);
        if (motor.equals("yerel")) {
            if (!YerelModel.hazir(c)) {
                Denetleyici.Sonuc s = Denetleyici.denetle(c, m);
                s.not = "Tablet içi model henüz indirilmedi · basit kontrol yapıldı";
                return s;
            }
            try {
                return YerelModel.denetle(c, m);
            } catch (Throwable t) {
                Denetleyici.Sonuc s = Denetleyici.denetle(c, m);
                s.not = "Tablet içi model çalışmadı (" + t.getClass().getSimpleName() + ") · basit kontrol yapıldı";
                return s;
            }
        }
        if (motor.equals("gemini") && Kayit.geminiVar(c)) {
            try {
                return GeminiDenetleyici.denetle(c, m);
            } catch (GeminiDenetleyici.GeminiHatasi h) {
                Denetleyici.Sonuc s = Denetleyici.denetle(c, m);
                s.not = turkce(h) + " · basit kontrol yapıldı";
                return s;
            }
        }
        return Denetleyici.denetle(c, m);
    }

    public static String turkce(GeminiDenetleyici.GeminiHatasi h) {
        switch (h.tur) {
            case "KOTA": return "Gemini'nin ücretsiz sınırı doldu";
            case "ANAHTAR": return "Gemini anahtarı geçersiz";
            case "ERISIM": return "Gemini erişimi reddedildi";
            case "BAGLANTI": return "Gemini'ye bağlanılamadı";
            case "MODEL": return "Uygun Gemini modeli bulunamadı";
            default: return "Gemini yanıtı okunamadı";
        }
    }
}
