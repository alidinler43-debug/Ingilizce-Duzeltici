#!/bin/bash
# İngilizce Düzeltici: GitHub'da APK'yı derler (proje klasöründen çalışır)
set -eo pipefail
cd "$(dirname "$0")"

# Yapay zekâ kütüphanesi Java 21 ile derlenmiş: varsa Java 21 kullan
for J in "$JAVA_HOME_21_X64" /usr/lib/jvm/temurin-21-jdk-amd64 /usr/lib/jvm/java-21-openjdk-amd64; do
  if [ -n "$J" ] && [ -x "$J/bin/java" ]; then
    export JAVA_HOME="$J"
    export PATH="$J/bin:$PATH"
    break
  fi
done
echo "Kullanılan Java: $JAVA_HOME"
java -version 2>&1 | head -n 1
echo "Gradle indiriliyor..."
wget -q https://services.gradle.org/distributions/gradle-8.9-bin.zip -O /tmp/gradle.zip
unzip -q -o /tmp/gradle.zip -d "$HOME"
"$HOME/gradle-8.9/bin/gradle" assembleRelease --no-daemon --stacktrace
cp app/build/outputs/apk/release/app-release.apk "$GITHUB_WORKSPACE/Duzeltici.apk"
echo "APK hazır."
