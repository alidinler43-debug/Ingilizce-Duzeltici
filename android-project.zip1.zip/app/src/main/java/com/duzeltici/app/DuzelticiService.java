package com.duzeltici.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.TextView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * WhatsApp açıkken ekranın köşesinde küçük bir kutu tutar. Gönderilen İngilizce mesajı
 * kontrol ettirir; yanlış yazılan her kelimeyi ve doğrusunu kutuda gösterir.
 * Mesaj metni yalnızca WhatsApp'tan okunur; diğer uygulamalarda sadece hangi uygulamanın
 * önde olduğuna bakılır (kutuyu gizlemek için).
 */
public class DuzelticiService extends AccessibilityService {

    private static final int KIRMIZI = 0xFFFF8A93;
    private static final int YESIL = 0xFF7CF0B8;
    private static final int SOLUK = 0xFFC9D3E3;
    private static final int BEYAZ = 0xFFFFFFFF;

    private final ExecutorService isci = Executors.newCachedThreadPool(); // takılan istek diğerlerini bekletmesin
    private int istekNo = 0;
    private int bekleyenIstek = 0;
    private final Handler anaIs = new Handler(Looper.getMainLooper());

    // ---- Mesaj yakalama ----
    private String sonMetin = "";
    private volatile String sonDenetlenen = "";
    private long sonDenetimZamani = 0;
    private String izlenenMetin = "";
    private boolean kontrolBekliyor = false;
    private AccessibilityNodeInfo alanDugumu;   // WhatsApp'ın mesaj yazma kutusu
    private String alanYontem = "";
    private boolean alanVar = false;
    private String okunan = "";                 // kutudaki teşhis satırı
    private String bilinenIpucu = "";           // boş kutuda görünen "Mesaj" gibi yazı

    // Yazarken canlı kontrol: yazmayı bıraktıktan kısa süre sonra cümleyi kontrol eder
    private String canliBekleyen = "";
    private final Runnable canliDenetim = () -> {
        String m = canliBekleyen;
        if (m.trim().length() >= 2 && !ipucuMu(m)) gonderildi(m);
    };

    // Boş mesaj kutusunda yazı gibi görünebilen ipuçları
    private static final String[] IPUCLARI = {
            "mesaj", "mesaj yazın", "bir mesaj yazın", "message", "type a message",
            "write a message", "mensaje", "nachricht"
    };
    private final Runnable durumKontrol = () -> {
        kontrolBekliyor = false;
        try {
            mesajKutusunuIzle();
        } catch (Exception ignored) {
        }
    };

    // ---- Ekrandaki kutu ----
    private WindowManager pencere;
    private TextView kutu;
    private CharSequence kutuIcerigi;
    private boolean kucuk = false;
    private long denemeBitis = 0;
    private long sonEklemeHatasi = 0;
    private boolean gorunurlukBekliyor = false;
    private final Runnable gorunurlukKontrol = () -> {
        gorunurlukBekliyor = false;
        try {
            gorunurluguAyarla();
        } catch (Exception ignored) {
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Teshis.servis = this;
        kutuIcerigi = hazirMetni();
        gorunurlukKontrolunuPlanla(300, true);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Teshis.servis = null;
        kutuyuGizle();
        return super.onUnbind(intent);
    }

    private static boolean whatsapp(CharSequence paket) {
        return paket != null && paket.toString().toLowerCase(Locale.ROOT).contains("whatsapp");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null) return;
        if (Teshis.servis == null) Teshis.servis = this;
        try {
            int tur = e.getEventType();
            if (tur == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) gorunurlukKontrolunuPlanla(250, true);
            if (!whatsapp(e.getPackageName())) return; // başka uygulamaların içeriği okunmaz

            Teshis.sonSinyal = System.currentTimeMillis();
            CharSequence sinif = e.getClassName();
            Teshis.sonOlay = AccessibilityEvent.eventTypeToString(tur) + " · " + sinif;
            if (kutu == null) gorunurlukKontrolunuPlanla(250, false);
            boolean yaziOlayi = tur == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
                    || tur == AccessibilityEvent.TYPE_VIEW_FOCUSED
                    || (tur == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                        && sinif != null && sinif.toString().contains("EditText"));
            if (yaziOlayi) {
                AccessibilityNodeInfo kaynak = e.getSource();
                if (kaynak != null && kaynak.isEditable() && !aramaKutusu(kaynak)) {
                    alanDugumu = kaynak;
                    alanYontem = "olay";
                }
            }
            durumKontrolunuPlanla();
            if (tur == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                yaziDegisti(e);
            } else if (tur == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                tiklandi(e);
            }
        } catch (Exception ignored) {
        }
    }

    // =====================================================================
    // Gönderilen mesajı yakalama
    // =====================================================================

    private void yaziDegisti(AccessibilityEvent e) {
        if (!mesajKutusu(e)) return;
        CharSequence once = e.getBeforeText();
        int silinen = e.getRemovedCount();
        String yeni = metinAl(e);
        if (once != null && silinen >= 2 && silinen == once.length()) {
            adayDegerlendir(once.toString(), yeni); // tüm yazı bir anda silindi
        }
        sonMetin = ipucuMu(yeni) ? "" : yeni;
        canliPlanla(sonMetin);
    }

    private void tiklandi(AccessibilityEvent e) {
        boolean gonder = false;
        AccessibilityNodeInfo n = e.getSource();
        if (n != null) {
            String id = n.getViewIdResourceName();
            if (id != null && id.endsWith(":id/send")) gonder = true;
        }
        CharSequence aciklama = e.getContentDescription();
        if (!gonder && aciklama != null) {
            String a = aciklama.toString().trim().toLowerCase(Locale.ROOT);
            if (a.equals("send") || a.equals("gönder")) gonder = true;
        }
        if (gonder && sonMetin.trim().length() >= 2) {
            String m = sonMetin;
            sonMetin = "";
            gonderildi(m);
        }
    }

    private void durumKontrolunuPlanla() {
        if (kontrolBekliyor) return;
        kontrolBekliyor = true;
        anaIs.postDelayed(durumKontrol, 120);
    }

    /** Mesaj yazma kutusunu doğrudan okur: doluyken bir anda boşaldıysa mesaj gönderilmiştir. */
    private void mesajKutusunuIzle() {
        AccessibilityNodeInfo alan = alanDugumu;
        if (alan != null) {
            boolean guncel;
            try {
                guncel = alan.refresh();
            } catch (Exception ex) {
                guncel = false;
            }
            if (!guncel) alan = null;
        }
        if (alan == null) {
            alan = alaniAra();
            alanDugumu = alan;
        }
        if (alan == null) {
            izlenenMetin = "";
            Teshis.alanBilgisi = "bulunamadı";
            okunanGuncelle(false, "");
            return;
        }
        String simdi = alanMetni(alan);
        CharSequence ip = alan.getHintText();
        if (ip != null && ip.length() > 0) bilinenIpucu = ip.toString().trim().toLowerCase(Locale.ROOT);
        String eski = izlenenMetin;
        izlenenMetin = simdi;
        if (!simdi.equals(eski)) {
            adayDegerlendir(eski, simdi);
            canliPlanla(ipucuMu(simdi) ? "" : simdi);
        }
        Teshis.alanBilgisi = alanYontem + " · " + alan.getViewIdResourceName() + " · " + alan.getClassName();
        okunanGuncelle(true, simdi);
    }

    /**
     * Mesaj kutusundaki yazı "eski"den "yeni"ye değişti. Kutu boşaldıysa ya da "Mesaj" ipucuna
     * döndüyse mesaj gönderilmiştir. Yazı tamamen başka bir şeye dönüştüyse, gönderilen mesajın
     * sohbette balon olarak görünüp görünmediğine bakarak karar verir.
     */
    private void adayDegerlendir(String eski, String yeni) {
        String e = eski.trim();
        if (e.length() < 2 || ipucuMu(e)) return;
        String y = yeni.trim();
        Teshis.sonAday = "“" + e + "” → “" + y + "”";
        if (y.isEmpty() || ipucuMu(y)) {
            gonderildi(e);
            return;
        }
        if (ortakOnek(e, y) == 0) {
            gonderimiDogrula(e, 0);
        }
    }

    private void canliPlanla(String metin) {
        if (metin.equals(canliBekleyen)) return;
        canliBekleyen = metin;
        anaIs.removeCallbacks(canliDenetim);
        if (metin.trim().length() >= 2) anaIs.postDelayed(canliDenetim, 1300);
    }

    private boolean ipucuMu(String metin) {
        if (metin == null) return false;
        String k = metin.trim().toLowerCase(Locale.ROOT);
        if (k.isEmpty()) return false;
        if (!bilinenIpucu.isEmpty() && k.equals(bilinenIpucu)) return true;
        for (String i : IPUCLARI) if (k.equals(i)) return true;
        return false;
    }

    private static int ortakOnek(String a, String b) {
        int n = Math.min(a.length(), b.length());
        int i = 0;
        while (i < n && a.charAt(i) == b.charAt(i)) i++;
        return i;
    }

    /** Gönderilen yazı sohbette balon olarak çıktı mı? Birkaç kez dener. */
    private void gonderimiDogrula(final String metin, final int deneme) {
        anaIs.postDelayed(() -> {
            boolean var = false;
            try {
                var = mesajBalonuVar(metin);
            } catch (Exception ignored) {
            }
            if (var) {
                gonderildi(metin);
            } else if (deneme < 3) {
                gonderimiDogrula(metin, deneme + 1);
            }
        }, deneme == 0 ? 300 : 700);
    }

    private boolean mesajBalonuVar(String metin) {
        for (AccessibilityNodeInfo kok : whatsappKokleri()) {
            ArrayDeque<AccessibilityNodeInfo> yigin = new ArrayDeque<>();
            yigin.push(kok);
            int sayac = 0;
            while (!yigin.isEmpty() && sayac < 3000) {
                AccessibilityNodeInfo n = yigin.pop();
                sayac++;
                if (!n.isEditable()) {
                    CharSequence t = n.getText();
                    if (t != null && t.toString().contains(metin)) return true;
                    CharSequence d = n.getContentDescription();
                    if (d != null && d.toString().contains(metin)) return true;
                }
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo c = n.getChild(i);
                    if (c != null) yigin.push(c);
                }
            }
        }
        return false;
    }

    private List<AccessibilityNodeInfo> whatsappKokleri() {
        List<AccessibilityNodeInfo> kokler = new ArrayList<>();
        try {
            AccessibilityNodeInfo aktif = getRootInActiveWindow();
            if (aktif != null && whatsapp(aktif.getPackageName())) kokler.add(aktif);
        } catch (Exception ignored) {
        }
        try {
            for (AccessibilityWindowInfo w : getWindows()) {
                AccessibilityNodeInfo r = w.getRoot();
                if (r != null && whatsapp(r.getPackageName())) kokler.add(r);
            }
        } catch (Exception ignored) {
        }
        return kokler;
    }

    /** WhatsApp pencerelerinde mesaj yazma kutusunu arar (kimlik, odak, en alttaki yazı alanı). */
    private AccessibilityNodeInfo alaniAra() {
        List<AccessibilityNodeInfo> kokler = whatsappKokleri();
        for (AccessibilityNodeInfo kok : kokler) {
            try {
                List<AccessibilityNodeInfo> l = kok.findAccessibilityNodeInfosByViewId(kok.getPackageName() + ":id/entry");
                if (l != null && !l.isEmpty()) {
                    alanYontem = "kimlik";
                    return l.get(0);
                }
            } catch (Exception ignored) {
            }
        }
        for (AccessibilityNodeInfo kok : kokler) {
            AccessibilityNodeInfo odak = kok.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if (odak != null && odak.isEditable() && !aramaKutusu(odak)) {
                alanYontem = "odak";
                return odak;
            }
        }
        for (AccessibilityNodeInfo kok : kokler) {
            AccessibilityNodeInfo bulunan = taraVeSec(kok);
            if (bulunan != null) {
                alanYontem = "tarama";
                return bulunan;
            }
        }
        return null;
    }

    /** Pencereyi tarar, ekranın en altındaki yazı alanını seçer (mesaj kutusu hep en alttadır). */
    private AccessibilityNodeInfo taraVeSec(AccessibilityNodeInfo kok) {
        List<AccessibilityNodeInfo> adaylar = new ArrayList<>();
        ArrayDeque<AccessibilityNodeInfo> yigin = new ArrayDeque<>();
        yigin.push(kok);
        int sayac = 0;
        while (!yigin.isEmpty() && sayac < 2500) {
            AccessibilityNodeInfo n = yigin.pop();
            sayac++;
            if (n.isEditable() && n.isVisibleToUser() && !aramaKutusu(n)) adaylar.add(n);
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) yigin.push(c);
            }
        }
        AccessibilityNodeInfo en = null;
        int enAlt = -1;
        Rect r = new Rect();
        for (AccessibilityNodeInfo aday : adaylar) {
            aday.getBoundsInScreen(r);
            if (r.bottom > enAlt) {
                enAlt = r.bottom;
                en = aday;
            }
        }
        return en;
    }

    private boolean aramaKutusu(AccessibilityNodeInfo n) {
        String id = n.getViewIdResourceName();
        if (id != null && id.toLowerCase(Locale.ROOT).contains("search")) return true;
        CharSequence ipucu = n.getHintText();
        if (ipucu != null) {
            String h = ipucu.toString().toLowerCase(Locale.ROOT);
            if (h.contains("search") || h.contains(" ara") || h.startsWith("ara")) return true;
        }
        return false;
    }

    private void okunanGuncelle(boolean var, String metin) {
        if (var == alanVar && metin.equals(okunan)) return;
        alanVar = var;
        okunan = metin;
        if (kutu != null && !kucuk) kutu.setText(gorunecekMetin());
    }

    private boolean mesajKutusu(AccessibilityEvent e) {
        AccessibilityNodeInfo n = e.getSource();
        String id = n != null ? n.getViewIdResourceName() : null;
        if (id != null) {
            if (id.endsWith(":id/entry")) return true;
            if (id.toLowerCase(Locale.ROOT).contains("search")) return false;
        }
        CharSequence sinif = e.getClassName();
        return sinif != null && sinif.toString().contains("EditText");
    }

    private String alanMetni(AccessibilityNodeInfo n) {
        if (n.isShowingHintText()) return "";
        CharSequence t = n.getText();
        if (t == null) return "";
        CharSequence ipucu = n.getHintText();
        if (ipucu != null && ipucu.toString().equals(t.toString())) return "";
        return t.toString();
    }

    private String metinAl(AccessibilityEvent e) {
        AccessibilityNodeInfo n = e.getSource();
        if (n != null && n.getText() != null) return alanMetni(n);
        List<CharSequence> parcalar = e.getText();
        StringBuilder sb = new StringBuilder();
        for (CharSequence p : parcalar) if (p != null) sb.append(p);
        return sb.toString();
    }

    private void gonderildi(String metin) {
        final String m = metin.trim();
        if (m.length() < 2 || ipucuMu(m)) return;
        long simdi = System.currentTimeMillis();
        if (m.equals(sonDenetlenen)) return; // bu cümlenin sonucu zaten kutuda
        sonDenetlenen = m;
        sonDenetimZamani = simdi;
        Teshis.sonYakalanan = m;
        Teshis.sonYakalananZaman = simdi;
        if (!Denetleyici.denetlenmeli(m)) {
            Teshis.sonSonuc = "Kontrol edilmedi (Türkçe harf var ya da çok kısa)";
            return;
        }
        Teshis.sonSonuc = "Kontrol ediliyor…";
        SpannableStringBuilder bekle = new SpannableStringBuilder();
        ekle(bekle, "⏳ Kontrol ediliyor: ", SOLUK, false, false, 0.9f);
        ekle(bekle, m, BEYAZ, false, false, 0.9f);
        kutuyuGuncelle(bekle, false);

        final Context c = getApplicationContext();
        final int no = ++istekNo;
        bekleyenIstek = no;
        final long baslangic = System.currentTimeMillis();

        // Bekçi: sunucu 12 saniyede yanıt vermezse "⏳" sonsuza kadar kalmasın
        anaIs.postDelayed(() -> {
            if (bekleyenIstek == no) {
                bekleyenIstek = 0;
                sonDenetlenen = "";
                Teshis.sonSonuc = "Sunucudan 12 sn içinde yanıt gelmedi";
                SpannableStringBuilder t = new SpannableStringBuilder();
                ekle(t, "⚠️ Kontrol sunucusundan yanıt gelmedi", SOLUK, false, false, 0.9f);
                t.append("\n");
                ekle(t, "İnternet bağlantısını ve uygulamanın internet iznini kontrol et", SOLUK, false, false, 0.8f);
                kutuyuGuncelle(t, true);
            }
        }, 12000);

        isci.execute(() -> {
            Denetleyici.Sonuc s = null;
            Throwable hata = null;
            try {
                s = Denetleyici.denetle(c, m);
            } catch (Throwable t) {
                hata = t;
            }
            final Denetleyici.Sonuc sonuc = s;
            final Throwable sorun = hata;
            final double sure = (System.currentTimeMillis() - baslangic) / 1000.0;
            final boolean dogruyuGoster = Kayit.dogruyuGoster(c);
            if (sonuc != null && !sonuc.hatalar.isEmpty()) Kayit.ekle(c, sonuc);
            anaIs.post(() -> sonucuIsle(no, m, sonuc, sorun, sure, dogruyuGoster));
        });
    }

    /** Sunucudan dönen sonucu kutuya yazar (yalnızca en son istek için). */
    private void sonucuIsle(int no, String m, Denetleyici.Sonuc s, Throwable sorun, double sure, boolean dogruyuGoster) {
        if (no != istekNo) return; // daha yeni bir kontrol başlamış
        bekleyenIstek = 0;
        String saniye = String.format(Locale.ROOT, "%.1f sn", sure);
        if (sorun != null) {
            sonDenetlenen = ""; // sonra yeniden denenebilsin
            String neden = sorun.getClass().getSimpleName() + ": " + sorun.getMessage();
            Teshis.sonSonuc = "Bağlantı hatası (" + saniye + "): " + neden;
            SpannableStringBuilder t = new SpannableStringBuilder();
            ekle(t, String.valueOf(sorun.getMessage()).contains("429")
                    ? "⚠️ Kontrol sınırı doldu, birkaç saniye bekle"
                    : "⚠️ Kontrol sunucusuna ulaşılamadı", SOLUK, false, false, 0.9f);
            t.append("\n");
            ekle(t, neden, SOLUK, false, false, 0.75f);
            kutuyuGuncelle(t, true);
            return;
        }
        if (s.ingilizceDegil) {
            Teshis.sonSonuc = "İngilizce algılanmadı (dil: " + s.dil + ")";
            SpannableStringBuilder t = new SpannableStringBuilder();
            ekle(t, "ℹ️ İngilizce algılanmadı: ", SOLUK, false, false, 0.9f);
            ekle(t, m, BEYAZ, false, false, 0.9f);
            kutuyuGuncelle(t, false);
            return;
        }
        Teshis.sonSonuc = (s.hatalar.isEmpty() ? "Hata yok" : s.hatalar.size() + " hata bulundu") + " (" + saniye + ")";
        sonucGoster(s, dogruyuGoster);
    }

    // =====================================================================
    // Kutunun içeriği
    // =====================================================================

    private CharSequence hazirMetni() {
        SpannableStringBuilder t = new SpannableStringBuilder();
        ekle(t, "✏️ İngilizce Düzeltici açık", BEYAZ, false, true, 0.95f);
        t.append("\n");
        ekle(t, "İngilizce mesaj gönder, burada kontrol ederim", SOLUK, false, false, 0.8f);
        return t;
    }

    /** Yanlış yazılan her kelime → doğrusu, altında cümlenin doğru hâli. */
    private void sonucGoster(Denetleyici.Sonuc s, boolean dogruyuGoster) {
        SpannableStringBuilder t = new SpannableStringBuilder();
        if (s.hatalar.isEmpty()) {
            if (!dogruyuGoster) {
                kutuyuGuncelle(hazirMetni(), false);
                return;
            }
            ekle(t, "✅ Doğru: ", YESIL, false, true, 1f);
            ekle(t, s.yazilan, BEYAZ, false, false, 1f);
            kutuyuGuncelle(t, true);
            return;
        }
        int adet = 0;
        for (Denetleyici.Hata h : s.hatalar) {
            if (adet == 6) break;
            if (adet > 0) t.append("\n");
            ekle(t, "❌ ", KIRMIZI, false, false, 1f);
            ekle(t, h.yanlis, KIRMIZI, true, false, 1f);
            if (h.oneri != null) {
                ekle(t, "  →  ", SOLUK, false, false, 1f);
                ekle(t, h.oneri.isEmpty() ? "(sil)" : h.oneri, YESIL, false, true, 1f);
            } else {
                ekle(t, "  (öneri yok)", SOLUK, false, false, 0.85f);
            }
            adet++;
        }
        if (!s.dogrusu.equals(s.yazilan)) {
            t.append("\n");
            ekle(t, "✅ ", YESIL, false, false, 1f);
            ekle(t, s.dogrusu, YESIL, false, true, 1f);
        }
        kutuyuGuncelle(t, true);
    }

    /** Uygulamadaki "Kutuyu dene" düğmesi için örnek gösterim. */
    public void ornekKutu() {
        SpannableStringBuilder t = new SpannableStringBuilder();
        ekle(t, "❌ ", KIRMIZI, false, false, 1f);
        ekle(t, "does", KIRMIZI, true, false, 1f);
        ekle(t, "  →  ", SOLUK, false, false, 1f);
        ekle(t, "do", YESIL, false, true, 1f);
        t.append("\n");
        ekle(t, "✅ ", YESIL, false, false, 1f);
        ekle(t, "do you swim", YESIL, false, true, 1f);
        t.append("\n");
        ekle(t, "Deneme kutusu", SOLUK, false, false, 0.8f);
        final CharSequence onceki = kutuIcerigi;
        final CharSequence ornek = t;
        denemeBitis = System.currentTimeMillis() + 6000;
        kutuyuGuncelle(ornek, true);
        gorunurlukKontrolunuPlanla(0, true);
        anaIs.postDelayed(() -> {
            if (kutuIcerigi == ornek) kutuyuGuncelle(onceki != null ? onceki : hazirMetni(), false);
            gorunurlukKontrolunuPlanla(0, true);
        }, 6100);
    }

    private void ekle(SpannableStringBuilder t, String s, int renk, boolean ustuCizili, boolean kalin, float boyut) {
        int b = t.length();
        t.append(s);
        int son = t.length();
        t.setSpan(new ForegroundColorSpan(renk), b, son, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (ustuCizili) t.setSpan(new StrikethroughSpan(), b, son, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (kalin) t.setSpan(new StyleSpan(Typeface.BOLD), b, son, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (boyut != 1f) t.setSpan(new RelativeSizeSpan(boyut), b, son, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void kutuyuGuncelle(CharSequence icerik, boolean ac) {
        kutuIcerigi = icerik;
        if (ac) kucuk = false;
        if (kutu != null) {
            kutu.setText(gorunecekMetin());
        } else {
            gorunurlukKontrolunuPlanla(0, true);
        }
    }

    private CharSequence gorunecekMetin() {
        if (kucuk) return "✏️";
        SpannableStringBuilder t = new SpannableStringBuilder(kutuIcerigi != null ? kutuIcerigi : hazirMetni());
        if (Kayit.teshisSatiri(this)) {
            t.append("\n");
            String satir;
            if (!alanVar) {
                satir = "Okunan: yazı alanı bulunamadı";
            } else {
                if (okunan.trim().isEmpty() || ipucuMu(okunan)) {
                    satir = "Okunan: (boş)";
                } else {
                    String k = okunan.length() > 40 ? "…" + okunan.substring(okunan.length() - 40) : okunan;
                    satir = "Okunan: “" + k + "”";
                }
            }
            ekle(t, satir, 0xFF8FA0BC, false, false, 0.75f);
        }
        return t;
    }

    // =====================================================================
    // Kutunun görünmesi: yalnızca WhatsApp öndeyken
    // =====================================================================

    private void gorunurlukKontrolunuPlanla(long gecikme, boolean acil) {
        if (gorunurlukBekliyor && !acil) return;
        anaIs.removeCallbacks(gorunurlukKontrol);
        gorunurlukBekliyor = true;
        anaIs.postDelayed(gorunurlukKontrol, gecikme);
    }

    private void gorunurluguAyarla() {
        boolean goster;
        if (System.currentTimeMillis() < denemeBitis) {
            goster = true;
        } else {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && !pm.isInteractive()) {
                goster = false;
            } else {
                AccessibilityNodeInfo kok = getRootInActiveWindow();
                if (kok == null || kok.getPackageName() == null) {
                    goster = kutu != null; // emin değilsek olduğu gibi bırak
                } else {
                    goster = whatsapp(kok.getPackageName());
                }
            }
        }
        if (goster) kutuyuGoster();
        else kutuyuGizle();
        if (kutu != null) gorunurlukKontrolunuPlanla(1500, false);
    }

    private void kutuyuGoster() {
        if (kutu != null) return;
        if (System.currentTimeMillis() - sonEklemeHatasi < 5000) return;
        if (pencere == null) pencere = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (pencere == null) return;
        if (kutuEkle(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)) {
            Teshis.kutuHatasi = null;
            return;
        }
        if (Settings.canDrawOverlays(this) && kutuEkle(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)) {
            Teshis.kutuHatasi = "Yedek yöntemle gösteriliyor";
            return;
        }
        sonEklemeHatasi = System.currentTimeMillis();
    }

    private boolean kutuEkle(int tip) {
        TextView tv = new TextView(this);
        tv.setTextColor(BEYAZ);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tv.setLineSpacing(0, 1.12f);
        int genislik = getResources().getDisplayMetrics().widthPixels;
        tv.setMaxWidth(Math.min((int) (genislik * 0.9f), dp(440)));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xF014213D);
        g.setCornerRadius(dp(14));
        g.setStroke(dp(1), 0x55FFFFFF);
        tv.setBackground(g);
        tv.setPadding(dp(12), dp(8), dp(12), dp(9));
        tv.setText(gorunecekMetin());

        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                tip,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = Kayit.konumX(this, dp(16));
        lp.y = Kayit.konumY(this, dp(80));
        surukleVeDokun(tv, lp);

        try {
            pencere.addView(tv, lp);
        } catch (Exception ex) {
            Teshis.kutuHatasi = ex.toString();
            return false;
        }
        kutu = tv;
        return true;
    }

    /** Dokununca küçülür/büyür; sürüklenince yeni yeri hatırlanır. */
    private void surukleVeDokun(final TextView tv, final WindowManager.LayoutParams lp) {
        tv.setOnTouchListener(new View.OnTouchListener() {
            private float bx, by;
            private int ilkX, ilkY;
            private boolean suruklendi;

            @Override
            public boolean onTouch(View v, MotionEvent ev) {
                switch (ev.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        bx = ev.getRawX();
                        by = ev.getRawY();
                        ilkX = lp.x;
                        ilkY = lp.y;
                        suruklendi = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = Math.round(ev.getRawX() - bx);
                        int dy = Math.round(ev.getRawY() - by);
                        if (!suruklendi && (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8))) suruklendi = true;
                        if (suruklendi) {
                            lp.x = Math.max(0, ilkX - dx); // sağ kenardan uzaklık
                            lp.y = Math.max(0, ilkY + dy);
                            try {
                                pencere.updateViewLayout(v, lp);
                            } catch (Exception ignored) {
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (suruklendi) {
                            Kayit.konumKaydet(getApplicationContext(), lp.x, lp.y);
                        } else {
                            kucuk = !kucuk;
                            tv.setText(gorunecekMetin());
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void kutuyuGizle() {
        if (kutu != null && pencere != null) {
            try {
                pencere.removeView(kutu);
            } catch (Exception ignored) {
            }
        }
        kutu = null;
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        Teshis.servis = null;
        anaIs.removeCallbacks(durumKontrol);
        anaIs.removeCallbacks(gorunurlukKontrol);
        anaIs.removeCallbacks(canliDenetim);
        kutuyuGizle();
        isci.shutdown();
        super.onDestroy();
    }
}
