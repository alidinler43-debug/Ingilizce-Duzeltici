package com.duzeltici.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * WhatsApp açıkken ekranın köşesinde küçük bir kutu tutar. Gönderilen İngilizce mesajı
 * kontrol ettirir; yanlış yazılan her kelimeyi ve doğrusunu kutuda gösterir.
 * Mesaj metni yalnızca WhatsApp'tan okunur; diğer uygulamalarda sadece hangi uygulamanın
 * önde olduğuna bakılır (kutuyu gizlemek için).
 */
public class DuzelticiService extends AccessibilityService {

    private static final int KIRMIZI = 0xFFFF8A93;
    private static final int YESIL = 0xFF7CF0B8;
    private static final int SOLUK = 0xFFC9D3E3;
    private static final int BEYAZ = 0xFFFFFFFF;

    private final ExecutorService isci = Executors.newSingleThreadExecutor();
    private final Handler anaIs = new Handler(Looper.getMainLooper());

    // ---- Mesaj yakalama ----
    private String sonMetin = "";
    private String sonDenetlenen = "";
    private long sonDenetimZamani = 0;
    private String izlenenMetin = "";
    private boolean kontrolBekliyor = false;
    private final Runnable durumKontrol = () -> {
        kontrolBekliyor = false;
        try {
            mesajKutusunuIzle();
        } catch (Exception ignored) {
        }
    };

    // ---- Ekrandaki kutu ----
    private WindowManager pencere;
    private TextView kutu;
    private CharSequence kutuIcerigi;
    private boolean kucuk = false;
    private long denemeBitis = 0;
    private long sonEklemeHatasi = 0;
    private boolean gorunurlukBekliyor = false;
    private final Runnable gorunurlukKontrol = () -> {
        gorunurlukBekliyor = false;
        try {
            gorunurluguAyarla();
        } catch (Exception ignored) {
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Teshis.servis = this;
        kutuIcerigi = hazirMetni();
        gorunurlukKontrolunuPlanla(300, true);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Teshis.servis = null;
        kutuyuGizle();
        return super.onUnbind(intent);
    }

    private static boolean whatsapp(CharSequence paket) {
        return paket != null && paket.toString().toLowerCase(Locale.ROOT).contains("whatsapp");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null) return;
        if (Teshis.servis == null) Teshis.servis = this;
        try {
            int tur = e.getEventType();
            if (tur == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) gorunurlukKontrolunuPlanla(250, true);
            if (!whatsapp(e.getPackageName())) return; // başka uygulamaların içeriği okunmaz

            Teshis.sonSinyal = System.currentTimeMillis();
            if (kutu == null) gorunurlukKontrolunuPlanla(250, false);
            durumKontrolunuPlanla();
            if (tur == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                yaziDegisti(e);
            } else if (tur == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                tiklandi(e);
            }
        } catch (Exception ignored) {
        }
    }

    // =====================================================================
    // Gönderilen mesajı yakalama
    // =====================================================================

    private void yaziDegisti(AccessibilityEvent e) {
        if (!mesajKutusu(e)) return;
        CharSequence once = e.getBeforeText();
        int eklenen = e.getAddedCount();
        int silinen = e.getRemovedCount();
        if (once != null && eklenen == 0 && silinen > 0 && silinen == once.length()) {
            sonMetin = "";
            if (silinen >= 2) gonderildi(once.toString()); // bir anda boşaldı: gönderildi
            return;
        }
        sonMetin = metinAl(e);
    }

    private void tiklandi(AccessibilityEvent e) {
        boolean gonder = false;
        AccessibilityNodeInfo n = e.getSource();
        if (n != null) {
            String id = n.getViewIdResourceName();
            if (id != null && id.endsWith(":id/send")) gonder = true;
        }
        CharSequence aciklama = e.getContentDescription();
        if (!gonder && aciklama != null) {
            String a = aciklama.toString().trim().toLowerCase(Locale.ROOT);
            if (a.equals("send") || a.equals("gönder")) gonder = true;
        }
        if (gonder && sonMetin.trim().length() >= 2) {
            String m = sonMetin;
            sonMetin = "";
            gonderildi(m);
        }
    }

    private void durumKontrolunuPlanla() {
        if (kontrolBekliyor) return;
        kontrolBekliyor = true;
        anaIs.postDelayed(durumKontrol, 120);
    }

    /** Mesaj yazma kutusunu doğrudan okur: doluyken bir anda boşaldıysa mesaj gönderilmiştir. */
    private void mesajKutusunuIzle() {
        AccessibilityNodeInfo kok = getRootInActiveWindow();
        if (kok == null) return;
        CharSequence paket = kok.getPackageName();
        if (!whatsapp(paket)) return;

        AccessibilityNodeInfo alan = yaziAlaniniBul(kok, paket.toString());
        if (alan == null) {
            izlenenMetin = "";
            return;
        }
        String simdi = alanMetni(alan);
        if (simdi.trim().isEmpty() && izlenenMetin.trim().length() >= 2) {
            gonderildi(izlenenMetin);
        }
        izlenenMetin = simdi;
    }

    private AccessibilityNodeInfo yaziAlaniniBul(AccessibilityNodeInfo kok, String paket) {
        try {
            List<AccessibilityNodeInfo> l = kok.findAccessibilityNodeInfosByViewId(paket + ":id/entry");
            if (l != null && !l.isEmpty()) return l.get(0);
        } catch (Exception ignored) {
        }
        AccessibilityNodeInfo odak = kok.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (odak != null && odak.isEditable()) {
            String id = odak.getViewIdResourceName();
            if (id != null && id.toLowerCase(Locale.ROOT).contains("search")) return null;
            return odak;
        }
        return null;
    }

    private boolean mesajKutusu(AccessibilityEvent e) {
        AccessibilityNodeInfo n = e.getSource();
        String id = n != null ? n.getViewIdResourceName() : null;
        if (id != null) {
            if (id.endsWith(":id/entry")) return true;
            if (id.toLowerCase(Locale.ROOT).contains("search")) return false;
        }
        CharSequence sinif = e.getClassName();
        return sinif != null && sinif.toString().contains("EditText");
    }

    private String alanMetni(AccessibilityNodeInfo n) {
        if (n.isShowingHintText()) return "";
        CharSequence t = n.getText();
        if (t == null) return "";
        CharSequence ipucu = n.getHintText();
        if (ipucu != null && ipucu.toString().equals(t.toString())) return "";
        return t.toString();
    }

    private String metinAl(AccessibilityEvent e) {
        AccessibilityNodeInfo n = e.getSource();
        if (n != null && n.getText() != null) return alanMetni(n);
        List<CharSequence> parcalar = e.getText();
        StringBuilder sb = new StringBuilder();
        for (CharSequence p : parcalar) if (p != null) sb.append(p);
        return sb.toString();
    }

    private void gonderildi(String metin) {
        final String m = metin.trim();
        long simdi = System.currentTimeMillis();
        if (m.equals(sonDenetlenen) && simdi - sonDenetimZamani < 15000) return; // aynı mesaj iki kez yakalandıysa
        sonDenetlenen = m;
        sonDenetimZamani = simdi;
        Teshis.sonYakalanan = m;
        Teshis.sonYakalananZaman = simdi;
        if (!Denetleyici.denetlenmeli(m)) {
            Teshis.sonSonuc = "Kontrol edilmedi (Türkçe harf var ya da çok kısa)";
            return;
        }
        Teshis.sonSonuc = "Kontrol ediliyor…";
        SpannableStringBuilder bekle = new SpannableStringBuilder();
        ekle(bekle, "⏳ Kontrol ediliyor: ", SOLUK, false, false, 0.9f);
        ekle(bekle, m, BEYAZ, false, false, 0.9f);
        kutuyuGuncelle(bekle, false);

        final Context c = getApplicationContext();
        isci.execute(() -> {
            Denetleyici.Sonuc s;
            try {
                s = Denetleyici.denetle(c, m);
            } catch (Exception hata) {
                Teshis.sonSonuc = "Bağlantı hatası: " + hata.getMessage();
                anaIs.post(() -> {
                    SpannableStringBuilder t = new SpannableStringBuilder();
                    ekle(t, "⚠️ İnternet yok, son mesaj kontrol edilemedi", SOLUK, false, false, 0.9f);
                    kutuyuGuncelle(t, true);
                });
                return;
            }
            if (s.ingilizceDegil) {
                Teshis.sonSonuc = "İngilizce algılanmadı (dil: " + s.dil + ")";
                anaIs.post(() -> {
                    SpannableStringBuilder t = new SpannableStringBuilder();
                    ekle(t, "ℹ️ İngilizce algılanmadı: ", SOLUK, false, false, 0.9f);
                    ekle(t, m, BEYAZ, false, false, 0.9f);
                    kutuyuGuncelle(t, false);
                });
                return;
            }
            Teshis.sonSonuc = s.hatalar.isEmpty() ? "Hata yok" : s.hatalar.size() + " hata bulundu";
            if (!s.hatalar.isEmpty()) Kayit.ekle(c, s);
            final Denetleyici.Sonuc son = s;
            final boolean dogruyuGoster = Kayit.dogruyuGoster(c);
            anaIs.post(() -> sonucGoster(son, dogruyuGoster));
        });
    }

    // =====================================================================
    // Kutunun içeriği
    // =====================================================================

    private CharSequence hazirMetni() {
        SpannableStringBuilder t = new SpannableStringBuilder();
        ekle(t, "✏️ İngilizce Düzeltici açık", BEYAZ, false, true, 0.95f);
        t.append("\n");
        ekle(t, "İngilizce mesaj gönder, burada kontrol ederim", SOLUK, false, false, 0.8f);
        return t;
    }

    /** Yanlış yazılan her kelime → doğrusu, altında cümlenin doğru hâli. */
    private void sonucGoster(Denetleyici.Sonuc s, boolean dogruyuGoster) {
        SpannableStringBuilder t = new SpannableStringBuilder();
        if (s.hatalar.isEmpty()) {
            if (!dogruyuGoster) {
                kutuyuGuncelle(hazirMetni(), false);
                return;
            }
            ekle(t, "✅ Doğru: ", YESIL, false, true, 1f);
            ekle(t, s.yazilan, BEYAZ, false, false, 1f);
            kutuyuGuncelle(t, true);
            return;
        }
        int adet = 0;
        for (Denetleyici.Hata h : s.hatalar) {
            if (adet == 6) break;
            if (adet > 0) t.append("\n");
            ekle(t, "❌ ", KIRMIZI, false, false, 1f);
            ekle(t, h.yanlis, KIRMIZI, true, false, 1f);
            if (h.oneri != null) {
                ekle(t, "  →  ", SOLUK, false, false, 1f);
                ekle(t, h.oneri.isEmpty() ? "(sil)" : h.oneri, YESIL, false, true, 1f);
            } else {
                ekle(t, "  (öneri yok)", SOLUK, false, false, 0.85f);
            }
            adet++;
        }
        if (!s.dogrusu.equals(s.yazilan)) {
            t.append("\n");
            ekle(t, "✅ ", YESIL, false, false, 1f);
            ekle(t, s.dogrusu, YESIL, false, true, 1f);
        }
        kutuyuGuncelle(t, true);
    }

    /** Uygulamadaki "Kutuyu dene" düğmesi için örnek gösterim. */
    public void ornekKutu() {
        SpannableStringBuilder t = new SpannableStringBuilder();
        ekle(t, "❌ ", KIRMIZI, false, false, 1f);
        ekle(t, "does", KIRMIZI, true, false, 1f);
        ekle(t, "  →  ", SOLUK, false, false, 1f);
        ekle(t, "do", YESIL, false, true, 1f);
        t.append("\n");
        ekle(t, "✅ ", YESIL, false, false, 1f);
        ekle(t, "do you swim", YESIL, false, true, 1f);
        t.append("\n");
        ekle(t, "Deneme kutusu", SOLUK, false, false, 0.8f);
        final CharSequence onceki = kutuIcerigi;
        final CharSequence ornek = t;
        denemeBitis = System.currentTimeMillis() + 6000;
        kutuyuGuncelle(ornek, true);
        gorunurlukKontrolunuPlanla(0, true);
        anaIs.postDelayed(() -> {
            if (kutuIcerigi == ornek) kutuyuGuncelle(onceki != null ? onceki : hazirMetni(), false);
            gorunurlukKontrolunuPlanla(0, true);
        }, 6100);
    }

    private void ekle(SpannableStringBuilder t, String s, int renk, boolean ustuCizili, boolean kalin, float boyut) {
        int b = t.length();
        t.append(s);
        int son = t.length();
        t.setSpan(new ForegroundColorSpan(renk), b, son, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (ustuCizili) t.setSpan(new StrikethroughSpan(), b, son, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (kalin) t.setSpan(new StyleSpan(Typeface.BOLD), b, son, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (boyut != 1f) t.setSpan(new RelativeSizeSpan(boyut), b, son, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void kutuyuGuncelle(CharSequence icerik, boolean ac) {
        kutuIcerigi = icerik;
        if (ac) kucuk = false;
        if (kutu != null) {
            kutu.setText(gorunecekMetin());
        } else {
            gorunurlukKontrolunuPlanla(0, true);
        }
    }

    private CharSequence gorunecekMetin() {
        if (kucuk) return "✏️";
        return kutuIcerigi != null ? kutuIcerigi : hazirMetni();
    }

    // =====================================================================
    // Kutunun görünmesi: yalnızca WhatsApp öndeyken
    // =====================================================================

    private void gorunurlukKontrolunuPlanla(long gecikme, boolean acil) {
        if (gorunurlukBekliyor && !acil) return;
        anaIs.removeCallbacks(gorunurlukKontrol);
        gorunurlukBekliyor = true;
        anaIs.postDelayed(gorunurlukKontrol, gecikme);
    }

    private void gorunurluguAyarla() {
        boolean goster;
        if (System.currentTimeMillis() < denemeBitis) {
            goster = true;
        } else {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && !pm.isInteractive()) {
                goster = false;
            } else {
                AccessibilityNodeInfo kok = getRootInActiveWindow();
                if (kok == null || kok.getPackageName() == null) {
                    goster = kutu != null; // emin değilsek olduğu gibi bırak
                } else {
                    goster = whatsapp(kok.getPackageName());
                }
            }
        }
        if (goster) kutuyuGoster();
        else kutuyuGizle();
        if (kutu != null) gorunurlukKontrolunuPlanla(1500, false);
    }

    private void kutuyuGoster() {
        if (kutu != null) return;
        if (System.currentTimeMillis() - sonEklemeHatasi < 5000) return;
        if (pencere == null) pencere = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (pencere == null) return;
        if (kutuEkle(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)) {
            Teshis.kutuHatasi = null;
            return;
        }
        if (Settings.canDrawOverlays(this) && kutuEkle(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)) {
            Teshis.kutuHatasi = "Yedek yöntemle gösteriliyor";
            return;
        }
        sonEklemeHatasi = System.currentTimeMillis();
    }

    private boolean kutuEkle(int tip) {
        TextView tv = new TextView(this);
        tv.setTextColor(BEYAZ);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tv.setLineSpacing(0, 1.12f);
        int genislik = getResources().getDisplayMetrics().widthPixels;
        tv.setMaxWidth(Math.min((int) (genislik * 0.9f), dp(440)));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xF014213D);
        g.setCornerRadius(dp(14));
        g.setStroke(dp(1), 0x55FFFFFF);
        tv.setBackground(g);
        tv.setPadding(dp(12), dp(8), dp(12), dp(9));
        tv.setText(gorunecekMetin());

        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                tip,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = Kayit.konumX(this, dp(16));
        lp.y = Kayit.konumY(this, dp(80));
        surukleVeDokun(tv, lp);

        try {
            pencere.addView(tv, lp);
        } catch (Exception ex) {
            Teshis.kutuHatasi = ex.toString();
            return false;
        }
        kutu = tv;
        return true;
    }

    /** Dokununca küçülür/büyür; sürüklenince yeni yeri hatırlanır. */
    private void surukleVeDokun(final TextView tv, final WindowManager.LayoutParams lp) {
        tv.setOnTouchListener(new View.OnTouchListener() {
            private float bx, by;
            private int ilkX, ilkY;
            private boolean suruklendi;

            @Override
            public boolean onTouch(View v, MotionEvent ev) {
                switch (ev.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        bx = ev.getRawX();
                        by = ev.getRawY();
                        ilkX = lp.x;
                        ilkY = lp.y;
                        suruklendi = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = Math.round(ev.getRawX() - bx);
                        int dy = Math.round(ev.getRawY() - by);
                        if (!suruklendi && (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8))) suruklendi = true;
                        if (suruklendi) {
                            lp.x = Math.max(0, ilkX - dx); // sağ kenardan uzaklık
                            lp.y = Math.max(0, ilkY + dy);
                            try {
                                pencere.updateViewLayout(v, lp);
                            } catch (Exception ignored) {
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (suruklendi) {
                            Kayit.konumKaydet(getApplicationContext(), lp.x, lp.y);
                        } else {
                            kucuk = !kucuk;
                            tv.setText(gorunecekMetin());
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void kutuyuGizle() {
        if (kutu != null && pencere != null) {
            try {
                pencere.removeView(kutu);
            } catch (Exception ignored) {
            }
        }
        kutu = null;
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        Teshis.servis = null;
        anaIs.removeCallbacks(durumKontrol);
        anaIs.removeCallbacks(gorunurlukKontrol);
        kutuyuGizle();
        isci.shutdown();
        super.onDestroy();
    }
}
